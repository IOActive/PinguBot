#!/bin/bash

# Initialize default values
input_dir=""
output_dir=""
no_of_files=0

# Parse the command-line arguments
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --input_dir) input_dir="$2"; shift ;;
        --output_dir) output_dir="$2"; shift ;;
        --no_of_files) no_of_files="$2"; shift ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

# Check if required arguments are provided
if [[ -z "$input_dir" || -z "$output_dir" || -z "$no_of_files" ]]; then
    echo "Error: Missing required arguments"
    echo "Usage: ./script.sh --input_dir <input_directory> --output_dir <output_directory> --no_of_files <file_count>"
    exit 1
fi

# Activate the virtual environment
source .venv/bin/activate

# Run the fuzzing command with the arguments
python ./examples/htmlparser/fuzz.py "$input_dir" --exact-artifact-path "$output_dir" --runs "$no_of_files"

