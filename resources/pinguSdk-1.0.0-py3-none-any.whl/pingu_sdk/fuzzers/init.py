
"""Fuzzing engine initialization."""

import importlib
from pingu_sdk import fuzzing
from pingu_sdk.fuzzers.engine import Engine as engine


def run(include_private=True, include_lowercase=False):
    """Initialise builtin fuzzing engines."""
    if include_private:
        engines = fuzzing.ENGINES
    else:
        engines = fuzzing.PUBLIC_ENGINES

    for engine_name in engines:
        try:
            module = f'pingu_sdk.fuzzers.{engine_name}.engine'
            mod = importlib.import_module(module)
            engine.register(engine_name, mod.Engine)
            if include_lowercase and engine_name.lower() != engine_name:
                engine.register(engine_name.lower(), mod.Engine)
        except Exception as e:
              print(e)


