
"""Android specific modulesplatforms.android"""

from pingu_sdk.platforms.android import app
from pingu_sdk.platforms.android import battery
from pingu_sdk.platforms.android import constants
from pingu_sdk.platforms.android import device
from pingu_sdk.platforms.android import emulator
from pingu_sdk.platforms.android import flash
from pingu_sdk.platforms.android import gestures
from pingu_sdk.platforms.android import logger
from pingu_sdk.platforms.android import sanitizer
from pingu_sdk.platforms.android import settings
from pingu_sdk.platforms.android import ui
from pingu_sdk.platforms.android import wifi
from pingu_sdk.platforms.android import adb
