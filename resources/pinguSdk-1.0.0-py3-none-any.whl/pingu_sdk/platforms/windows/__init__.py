
"""Windows specific modules."""

from . import gestures
