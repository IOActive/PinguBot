"""Blobs handling."""

import os
import uuid
from pingu_sdk.datastore.pingu_api.storage.blob_api import BlobsApi
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment, memoize
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

FAIL_NUM_RETRIES = 2
FAIL_WAIT = 1.5

# CS blob metadata key for filename.
BLOB_FILENAME_METADATA_KEY = 'filename'

class BlobsException(Exception):
    """Base exception for blobs module."""

class BlobInfo(object):
    """blob info."""

    def __init__(self,
                 project_id,
                 blob_name,
                 filename=None,
                 size=None,
                 ):
        self.project_id = project_id
        self.blob_name = blob_name

        if filename is not None and size is not None:
            self.filename = filename
            self.size = size
        else:
            blobs_api = get_api_client().storage_blobs_api
            blob_data = blobs_api.read_blob(self.project_id, self.blob_name)
            #self.filename = blob_data['filename']
            self.size = len(blob_data)

    def key(self):
        return self.blob_name

    @property
    def path(self):
        return self.blob_name

    @staticmethod
    def from_key(project_id, blob_name):
        try:
            return BlobInfo(project_id, blob_name)
        except Exception as e:
            logs.log_error('Failed to get blob from key %s.' % blob_name)
            return None

def get_blob_info(project_id, blob_name):
    """Get the BlobInfo for the given key."""
    return BlobInfo.from_key(project_id, blob_name)

def delete_blob(project_id, blob_name):
    """Delete a blob key."""
    blob_api = get_api_client().storage_blobs_api
    try:
        blob_api.delete_blob(project_id, blob_name)
        return True
    except Exception as e:
        logs.log_error(f"Failed to delete blob {blob_name}: {e}")
        return False

def write_blob(project_id, file_handle_or_path, file_size):
    """Write a single file testcase to blob storage."""
    blob_api = get_api_client().storage_blobs_api
    blob_name = generate_new_blob_name()

    if isinstance(file_handle_or_path, str):
        with open(file_handle_or_path, 'rb') as file:
            blob_data = file.read()
    else:
        blob_data = file_handle_or_path.read()

    try:
        blob_api.upload_blob(project_id, blob_name, blob_data)
        return blob_name
    except Exception as e:
        raise BlobsException(f'Failed to write blob {blob_name}: {e}')

def read_blob_to_disk(project_id, blob_name, local_file):
    """Copy data stored in the blobstore to a local file."""
    directory = os.path.dirname(local_file)
    if not os.path.exists(directory):
        os.makedirs(directory)

    blob_api = get_api_client().storage_blobs_api
    try:
        blob_data = blob_api.download_blob(project_id, blob_name)
        with open(local_file, 'wb') as file:
            file.write(blob_data)
        return True
    except Exception as e:
        logs.log_error(f"Failed to read blob {blob_name} to disk: {e}")
        return False

def read_key(project_id, blob_name):
    """Returns data associated with a blobstore key."""
    blob_api = get_api_client().storage_blobs_api
    try:
        return blob_api.read_blob(project_id, blob_name)
    except Exception as e:
        logs.log_error(f"Failed to read blob {blob_name}: {e}")
        return None

def generate_new_blob_name():
    """Generate a new blob name."""
    return str(uuid.uuid4()).lower()
