from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from bson import ObjectId
import six
from pingu_sdk.system import environment


class Job(BaseModel):
    """Definition of a job type used by the bots."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    name: str = ''
    project_id: UUID
    description: str = ''
    date: datetime = datetime.now()
    enabled: bool = True
    archived: bool = False
    template: Optional[UUID] = Field(default=None)
    environment_string: str = "CUSTOM_BINARY=false"
    platform: str
    # Blobstore key of the custom binary for this job.
    custom_binary_key: str = ''
    # Blobstore path of the custom binary for this job.
    custom_binary_path: str = ''
    # Filename for the custom binary.
    custom_binary_filename: str = ''
    # Revision of the custom binary.
    custom_binary_revision: int = 0

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

    # def __init__(self, json_job):
    #     self.name = json_job['name']
    #     self.description = json_job['description']
    #     self.date = json_job['date']['$date']
    #     self.enabled = json_job['enabled']
    #     self.archived = json_job['archived']
    #     self.fuzzing_target = json_job['fuzzing_target']['$oid']
    #     self.owner = json_job['owner']
    #     self.platform = json_job['platform']
    #     self.templates = json_job['template']
    #     self.environment_string = json_job['environment_string']

    def get_environment(self):
        """Get the environment as a dict for this job, including any environment
        variables in its template."""
        if not self.template:
            return environment.parse_environment_definition(self.environment_string)

        job_environment = {}
        for template in self.template:
            if not template:
                continue

            template_environment = environment.parse_environment_definition(
                template.environment_string)

            job_environment.update(template_environment)

        environment_overrides = environment.parse_environment_definition(
            self.environment_string)

        job_environment.update(environment_overrides)
        return job_environment

    def get_environment_string(self):
        """Get the environment string for this job, including any environment
        variables in its template. Avoid using this if possible."""
        environment_string = ''
        job_environment = self.get_environment()
        for key, value in six.iteritems(job_environment):
            environment_string += '%s = %s\n' % (key, value)

        return environment_string

