from typing import List, Optional
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from bson import ObjectId
from pingu_sdk.crash_analysis.stack_parsing.stack_parser import StackFrame

class CrashStats(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    testcase_id: Optional[UUID] = Field(default=None)
    project_id: UUID
    crash_id: Optional[UUID] = Field(default=None)
    job_id: UUID
    fuzzer_id: UUID
    
    crash_type: str = ""
    crash_state: str = ""
    platform: str
    crash_time_in_ms: int = 0
    security_flag: bool = False
    reproducible_flag: bool = False
    revision: int = 1
    new_flag: bool = False
