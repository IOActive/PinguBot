from enum import Enum
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from bson import ObjectId

class TestcaseVariantStatus(int, Enum):
    PENDING = 0
    REPRODUCIBLE = 1
    FLAKY = 2
    UNREPRODUCIBLE = 3

class TestcaseVariant(BaseModel):
    """Represent a testcase variant on another job (another platform / sanitizer / config)."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    # Testcase ID of the testcase for which the variant is being evaluated.
    testcase_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="testcase_id")

    # Status of the testcase variant (pending, reproducible, unreproducible, etc).
    status: TestcaseVariantStatus = TestcaseVariantStatus.PENDING

    # Job type for the testcase variant.
    job_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="job_id")

    # Revision that the testcase variant was tried against.
    revision: int = 0

    # Crash type.
    crash_type: str = ""

    # Crash state.
    crash_state: str = ""

    # Bool to indicate if it is a security bug?
    security_flag: bool = False

    # Bool to indicate if crash is similar to original testcase.
    is_similar: bool = False

    # Similar testcase reproducer key (optional). This is set in case we notice a
    # similar crash on another platform.
    reproducer_key: str = ""

    # Platform (e.g. windows, linux, android).
    platform: str = ""

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True  # required for the _id
        json_encoders = {ObjectId: str}

