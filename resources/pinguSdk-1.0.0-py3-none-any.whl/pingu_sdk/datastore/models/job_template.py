from uuid import UUID, uuid4
from pydantic import BaseModel, Field

class JobTemplate(BaseModel):
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    # Job template name.
    name: str
    # Environment string.
    environment_string: str