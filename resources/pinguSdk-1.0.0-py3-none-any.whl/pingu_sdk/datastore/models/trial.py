
from pydantic import BaseModel


class Trial(BaseModel):
    """Trials for specific binaries."""
    # App name that this trial is applied to. E.g. "d8" or "chrome".
    app_name: str

    # Chance to select this set of arguments. Zero to one.
    probability: float

    # Additional arguments to apply if selected.
    app_args: str