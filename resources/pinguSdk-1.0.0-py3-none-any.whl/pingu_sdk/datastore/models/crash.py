from typing import List, Optional
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from bson import ObjectId
from pingu_sdk.crash_analysis.stack_parsing.stack_parser import StackFrame

class Crash(BaseModel):
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    crash_signal: int = 1
    exploitability: str = ""
    crash_time: int = 0
    crash_hash: str = ""
    verified: bool = False
    additional: str = ""
    iteration: int = 0
    # Crash on an invalid read/write.
    crash_type: str = ""
    # Crashing address.
    crash_address: str = ""
    # First x stack frames.
    crash_state: str = ""
    # Complete stacktrace.
    crash_stacktrace: str = ""
    # Security severity of the bug.
    security_severity: Optional[int] = 0
    # The file on the bot that generated the testcase.
    absolute_path: str = ""
    # Security_flag
    security_flag: bool = False
    reproducible_flag: bool = False
    return_code: str = '-1'
    gestures: Optional[List[str]] = []
    resource_list: Optional[List[str]] = []
    fuzzing_strategy: dict = {}
    should_be_ignored: bool = False
    application_command_line: str = ""
    unsymbolized_crash_stacktrace: str = ""
    crash_frame: Optional[List[List[StackFrame]]] = []
    crash_info: Optional[str] = ""
    # Optional. Revision that we discovered the crash in.
    crash_revision: int = 1
    # Does the testcase crash stack vary b/w crashes ?
    flaky_stack: bool=False

    # References
    testcase_id: UUID

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True  # required for the _id
        json_encoders = {ObjectId: str}

