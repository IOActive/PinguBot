from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from typing import Optional


class BotConfiguration(BaseModel):
    id : UUID = Field(default_factory=uuid4)
    config_data: str
    bot_id: Optional[UUID] = Field(default=None)