from uuid import UUID, uuid4
from pydantic import BaseModel, Field

class FuzzStrategyProbability(BaseModel):
    """Mapping between fuzz strategies and probabilities with which they
  should be selected."""
    id: UUID = Field(default_factory=uuid4)
    strategy_name: str = ''
    probability: float = 1.0
    engine: UUID
