from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from typing import Optional


class Project(BaseModel):
    id : UUID = Field(default_factory=uuid4)
    name: str
    timestamp: datetime
    description: str
    configuration: str