from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class BuildMetadata(BaseModel):
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    """Metadata associated with a particular archived build."""
    # Job type that this build belongs to.
    job_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="job")

    # Revision of the build.
    revision: int

    # Good build or bad build
    bad_build: bool = False

    # Stdout and stderr.
    console_output: str

    # Bot name.
    bot_name: str

    # Symbol data.
    symbols: str = ""

    # Creation timestamp.
    timestamp: datetime
