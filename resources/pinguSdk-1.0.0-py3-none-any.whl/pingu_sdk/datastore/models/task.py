from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class Task(BaseModel):
    """Represent a testcase variant on another job (another platform / sanitizer / config)."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    
    # Platform (esp important for Android platform for OS version).
    platform: str = 'NA'
    
    command: str = ''
    
    argument: str = '' 
    
    # Task payload containing information on current task execution.
    payload: str = '' 

    # Expected end time for task.
    end_time : Optional[datetime] = None

    # Create time stamp of the task.
    create_time: Optional[datetime] = Field(default_factory=datetime.now)

    # Tasks status
    status: str = 'NA'
    
    job_id: UUID
