from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field

COVERAGE_INFORMATION_DATE_FORMAT = '%Y%m%d'

class CoverageInformation(BaseModel):
  """Coverage info."""
  id: UUID = Field(default_factory=uuid4)
  date: datetime = datetime.now()
  fuzzer_id: UUID
  
  # Function coverage information.
  functions_covered: int = 0
  functions_total: int = 0

  # Edge coverage information.
  edges_covered : int = 0
  edges_total : int = 0

  # Corpus size information.
  corpus_size_units : int = 0
  corpus_size_bytes : int = 0
  corpus_location : str = ""

  # Corpus backup information.
  corpus_backup_location : str = ""

  # Quarantine size information.
  quarantine_size_units : int = 0
  quarantine_size_bytes : int = 0
  quarantine_location  : str = ""

  # Link to the HTML report.
  html_report_url : str = ""

  def coverage_information_date_to_string(date: datetime):
    """Returns string representation of the date in a format used for coverage."""
    return date.strftime(COVERAGE_INFORMATION_DATE_FORMAT)