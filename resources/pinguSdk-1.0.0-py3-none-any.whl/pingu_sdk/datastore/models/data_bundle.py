from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class DataBundle(BaseModel):
    """Represents a data bundle associated with a fuzzer."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    VALID_NAME_REGEX: str

    # The data bundle's name (important for identifying shared bundles).
    name: str

    # Name of cloud storage bucket on Minio.
    bucket_name: str

    # Data bundle's source (for accountability).
    # TODO(ochang): Remove.
    source: str

    # If data bundle can be unpacked locally or needs nfs.
    is_local: bool = True

    # Creation timestamp.
    timestamp: datetime

    # Whether or not bundle should be synced to worker instead.
    # Fuzzer scripts are usually run on trusted hosts, so data bundles are synced
    # there. In libFuzzer's case, we want the bundle to be on the same machine as
    # where the libFuzzer binary will run (untrusted).
    sync_to_worker: bool = False