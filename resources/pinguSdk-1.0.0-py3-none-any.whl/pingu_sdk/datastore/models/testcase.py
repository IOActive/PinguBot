from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field, PrivateAttr
from pingu_sdk.datastore.models.fuzz_target import FuzzTarget
from pingu_sdk.system import environment
from typing import Dict, Optional
from uuid import UUID, uuid4
from bson import ObjectId

from pingu_sdk.utils import json_utils

class Status(str, Enum):
    PENDING = 'pending'
    ONGOING = 'processed'
    UNREPRODUCIBLE = 'unreproducible'
    DONE = 'done'

class Testcase(BaseModel):
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_idNameError: Private attributes must not use dunder names; use a single underscore prefix instead of '__metadata_cache__'.")
    bug_information: Optional[str] = ""
    # Testcase file
    test_case: str = ""
    fixed: str = 'NA'
    # Did the bug only reproduced once ?
    one_time_crasher_flag: bool = True
    comments: str = ""
    # The file on the bot that generated the testcase.
    absolute_path: str = "/"
    # Queue to publish tasks
    queue: str = ""
    archived: bool = False
    timestamp: datetime
    status: Status = Status.PENDING
    # indicating if cleanup triage needs to be done.
    triaged: bool = False
    # Whether testcase has a bug (either bug_information or group_bug_information).
    has_bug_flag: bool = False
    open: bool = True
    # State representing whether the fuzzed or minimized testcases are archived.
    archive_state: int = 0
    # store paths for various things like original testcase, minimized
    # testcase, etc.
    testcase_path: str = ""
    minimized_keys: str = ""
    minidump_keys: str = ""
    fuzzed_keys: str = ""

    # Metadata Cache
    additional_metadata: str = ""

    # Flag indicating if UBSan detection should be disabled. This is needed for
    # cases when ASan and UBSan are bundled in the same build configuration
    # and we need to disable UBSan in some runs to find the potentially more
    # interesting ASan bugs.
    disable_ubsan: bool = False

    # Minimized argument list.
    minimized_arguments: str = ""

    # Regression range.
    regression: str = ""

    # Adjusts timeout based on multiplier value.
    timeout_multiplier: float = 1.0

    # ASAN redzone size in bytes.
    redzone: int = 128

    # Testcase timeout.
    timeout: Optional[int] = 0

    # Number of retries for this testcase.
    retries: Optional[int] = 10

    quiet_flag: bool = False

    # References
    job_id: UUID  #PyObjectId = Field(default_factory=PyObjectId, alias="job_id")
    fuzzer_id: UUID  #PyObjectId = Field(default_factory=PyObjectId, alias="fuzzer_id")
    duplicate_of: Optional[UUID] = Field(default=None)

    _metadata_cache: Dict[str, int] = PrivateAttr(default_factory=dict)

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True  # required for the _id
        json_encoders = {ObjectId: str}

    def _ensure_metadata_is_cached(self):
        """Ensure that the metadata for this has been cached."""
        #if hasattr(self, '__metadata_cache__'):
        #    return

        try:
            cache = json_utils.loads(self.additional_metadata)
        except (TypeError, ValueError):
            cache = {}

        setattr(self, '_metadata_cache', cache)

    def get_metadata(self, key=None, default=None):
        """Get metadata for a test case. Slow on first access."""
        self._ensure_metadata_is_cached()

        # If no key is specified, return all metadata.
        if not key:
            return self._metadata_cache

        try:
            return self._metadata_cache[key]
        except KeyError:
            return default

    def set_metadata(self, key, value, update_testcase=True):
        """Set metadata for a test case."""
        self._ensure_metadata_is_cached()
        self._metadata_cache[key] = value

        self.additional_metadata = json_utils.dumps(self._metadata_cache)

    def delete_metadata(self, key, update_testcase=True):
        """Remove metadata key for a test case."""
        self._ensure_metadata_is_cached()

        # Make sure that the key exists in cache. If not, no work to do here.
        if key not in self._metadata_cache:
            return

        del self._metadata_cache[key]
        self.additional_metadata = json_utils.dumps(self._metadata_cache)

    def actual_fuzzer_name(self):
        """Actual fuzzer name, uses one from pingu_sdk.overridden attribute if available."""
        return self.fuzzer_id
    
    def get_fuzz_target(self):
        """Get the associated FuzzTarget entity for this test case."""
        name = self.actual_fuzzer_name()
        if not name:
            return None

        binary = self.get_metadata('fuzzer_binary_name')
        if not binary:
            # Not applicable.
            return None
                
        target = FuzzTarget(fuzzer_id=self.fuzzer_id, binary=binary)

        if environment.get_value('ORIGINAL_JOB_NAME'):
            # Overridden engine (e.g. for minimization).
            target.fuzzer_id = environment.get_engine_for_job()

        return target