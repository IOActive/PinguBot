from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from typing import Optional


class Bot(BaseModel):
    id : UUID = Field(default_factory=uuid4)
    name: str
    last_beat_time: Optional[datetime] = Field(default=None)
    platform: str
    current_task_id: Optional[UUID] = Field(default=None)