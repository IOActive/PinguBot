import re
from typing import Optional
from uuid import UUID, uuid4
from bson import ObjectId
from pydantic import BaseModel, Field

from pingu_sdk.utils import utils

# Regex to match special chars in project name.
SPECIAL_CHARS_REGEX = re.compile('[^a-zA-Z0-9_-]')

def fuzz_target_fully_qualified_name(engine, project, binary):
    """Get a fuzz target's fully qualified name."""
    return str(engine) + '_' + fuzz_target_project_qualified_name(str(project), binary)


def normalized_name(name):
    """Return normalized name with special chars like slash, colon, etc normalized
  to hyphen(-). This is important as otherwise these chars break local and cloud
  storage paths."""
    return SPECIAL_CHARS_REGEX.sub('-', name).strip('-')


def fuzz_target_project_qualified_name(project, binary):
    """Get a fuzz target's project qualified name."""
    binary = normalized_name(binary)
    if not project:
        return '_' + binary

    normalized_project_prefix = normalized_name(project) + '_'
    if binary.startswith(normalized_project_prefix):
        return binary

    return normalized_project_prefix + binary

class FuzzTarget(BaseModel):
    """Mapping between fuzz target and jobs with additional metadata for
      selection."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    # Selected Fuzzer
    fuzzer_id: UUID

    # Project name.
    project_id: Optional[UUID] = Field(default=None)

    # Binary name.
    binary: str

    # Target File
    # fuzzing_target: bytes

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True  # required for the _id
        json_encoders = {ObjectId: str}

    def fully_qualified_name(self):
        """Get the fully qualified name for this fuzz target."""
        return fuzz_target_fully_qualified_name(self.fuzzer_id, self.project_id,
                                                self.binary)

    def project_qualified_name(self):
        """Get the name qualified by project."""
        return fuzz_target_project_qualified_name(str(self.project_id), self.binary)
    
class FuzzTargetsCount(BaseModel):
    """Fuzz targets count for every job. Key IDs are the job name."""
    id: str
    count: int
