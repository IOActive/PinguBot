
from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from bson import ObjectId


def fuzz_target_job_key(fuzz_target_name, job):
    """Return the key for FuzzTargetJob."""
    return '{}/{}'.format(fuzz_target_name, job)


class FuzzTargetJob(BaseModel):
    """Mapping between fuzz target and jobs with additional metadata for
      selection."""
    id: UUID = Field(default_factory=uuid4) #PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    # Fully qualified fuzz target.
    fuzz_target_id: UUID

    # Job this target ran as.
    job_id: UUID

    # Engine this ran as.
    fuzzer_id: UUID

    # Relative frequency with which to select this fuzzer.
    weight: float = 1.0

    # Approximate last time this target was run.
    last_run: datetime = datetime.now()

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True  # required for the _id
        json_encoders = {ObjectId: str}

