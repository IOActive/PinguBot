from uuid import UUID
from pydantic import BaseModel


class ReportMetadata(BaseModel):
    """Metadata associated with a crash report."""
    # Job type from pingu_sdk.testcase.
    #job_type: PyObjectId = Field(default_factory=PyObjectId, alias="job_id")

    # Revision of build from pingu_sdk.report.
    crash_revision: int = -1

    # Has this report been successfully uploaded?
    is_uploaded: bool = False

    # Version.
    version: str = ''

    # Key to minidump previously written to blobstore.
    minidump_key: str = ''

    # Processed crash bytes.
    serialized_crash_stack_frames: str = ''

    # Id of the associated testcase.
    testcase_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="testcase_id")

    # Id of the associated bot.
    bot_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="bot_id")

    # Optional upload params, stored as a JSON object.
    optional_params: str = ''

    # Report id from pingu_sdk.crash/.
    crash_report_id: UUID #PyObjectId = Field(default_factory=PyObjectId, alias="crash_id")
