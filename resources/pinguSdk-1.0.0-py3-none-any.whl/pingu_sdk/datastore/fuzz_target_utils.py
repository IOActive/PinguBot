from typing import List
from pingu_sdk.datastore.models.fuzz_target import FuzzTarget
from pingu_sdk.datastore.models.fuzz_target_job import FuzzTargetJob
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client


"""Helper functions related to fuzz target entities."""


def get_fuzz_targets_for_target_jobs(target_jobs) -> List[FuzzTarget]:
    """Return corresponding FuzzTargets for the given FuzzTargetJobs."""
    fuzz_targets = []
    for target_job in target_jobs:
        fuzz_target = get_api_client().fuzz_target_api.get_fuzz_target_by_id(target_job.fuzz_target_id)
        fuzz_targets.append(fuzz_target)
    return fuzz_targets


def get_fuzz_target_jobs(fuzzer_id=None,
                         job_id=None) -> List[FuzzTargetJob]:
    """Return a Datastore query for fuzz target to job mappings."""
    api_client = get_api_client()
    if job_id:
        fuzz_target_jobs =api_client.fuzz_target_job_api.get_fuzz_target_jobs_by_job(job_id=job_id)
        return fuzz_target_jobs

    elif fuzzer_id:
        fuzz_target_jobs = api_client.fuzz_target_job_api.get_fuzz_target_jobs_by_engine(fuzzer_id=fuzzer_id)
        return fuzz_target_jobs




