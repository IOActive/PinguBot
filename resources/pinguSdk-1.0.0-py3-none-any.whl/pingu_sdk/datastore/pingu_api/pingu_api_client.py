from pingu_sdk.datastore.pingu_api import *
from pingu_sdk.datastore.pingu_api.storage.blob_api import BlobsApi
from pingu_sdk.datastore.pingu_api.storage.corpus_api import CorpusApi
from pingu_sdk.datastore.pingu_api.storage.coverage_api import CoverageApi
from pingu_sdk.datastore.pingu_api.storage.dictionaries_api import DictionariesApi
from pingu_sdk.datastore.pingu_api.storage.logs_api import LogsApi
from pingu_sdk.datastore.pingu_api.storage.stats_api import StatsApi
from pingu_sdk.datastore.pingu_api.storage.build_api import BuildApi
from pingu_sdk.system import environment

  
class PinguApiClient:
    def __init__(self, host: str, auth_token: str) -> None:
        """Initialize a new PinguApiClient."""
        self.pingu_api = PinguApi(host=host, auth_token=auth_token)
        self.bot_api = BotApi(host=host, auth_token=auth_token)
        self.build_metada_api = BuildMetadataApi(host=host, auth_token=auth_token)
        self.crash_api = CrashApi(host=host, auth_token=auth_token)
        self.fuzzer_api = FuzzerApi(host=host, auth_token=auth_token)
        self.databundle_api = DataBundleApi(host=host, auth_token=auth_token)
        self.fuzz_target_api = FuzzTargetApi(host=host, auth_token=auth_token)
        self.fuzz_target_job_api = FuzzTargetJobApi(host=host, auth_token=auth_token)
        self.job_api = JobApi(host=host, auth_token=auth_token)
        self.job_template_api = JobTemplateApi(host=host, auth_token=auth_token)
        self.task_api = TaskApi(host=host, auth_token=auth_token)
        self.testcase_api = TestcaseApi(host=host, auth_token=auth_token)
        self.testcase_variant_api = TestcaseVariantApi(host=host, auth_token=auth_token)
        self.trial_api = TrialApi(host=host, auth_token=auth_token)
        self.bot_config_api = BotConfigurationApi(host=host, auth_token=auth_token)
        self.project_api = ProjectApi(host=host, auth_token=auth_token)
        self.crash_stats_api = CrashStatsApi(host=host, auth_token=auth_token)
        self.storage_corpus_api = CorpusApi(host=host, auth_token=auth_token)
        self.storage_coverage_api = CoverageApi(host=host, auth_token=auth_token)
        self.storage_logs_api = LogsApi(host=host, auth_token=auth_token)
        self.storage_stats_api = StatsApi(host=host, auth_token=auth_token)
        self.storage_dictionaries_api = DictionariesApi(host=host, auth_token=auth_token)
        self.storage_blobs_api = BlobsApi(host=host, auth_token=auth_token)
        self.storage_build_api = BuildApi(host=host, auth_token=auth_token)
        
_api_client: PinguApiClient = None

def get_api_client():
    global _api_client  # Declare _api_client as global
    if not _api_client:
        _api_client = PinguApiClient(
            environment.get_value("PINGUAPI_HOST"),
            environment.get_value("PINGUAPI_KEY"),
        )
    return _api_client
