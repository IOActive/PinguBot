import json
from uuid import UUID
from pydantic import ValidationError
from pingu_sdk.datastore.models import Project
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
# ------------------------------------------------------------------------------
# Project API Implementaion
# ------------------------------------------------------------------------------

class ProjectApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "project"

    def get_project_by_name(self, project_name: str) -> Project:
        try:
            params= {"name": project_name}
            response = self.make_request(method='GET', path=self.path, params=params)
        except Exception as e:
            raise PinguAPIError('Failed to get project') from e
        
        result = json.loads(response.content.decode('utf-8'))
        if response.status_code == 200 and len(result["results"]) > 0:
            json_project = result["results"][0]
            try:
                return Project(**json_project)
            except ValidationError as e:
                raise PinguAPIError("Invalid project data received from.server") from e
            
    def get_project_by_id(self, project_id: UUID) -> Project:
        try:
            params= {"id": str(project_id)}
            response = self.make_request(method='GET', path=self.path, params=params)
        except Exception as e:
            raise PinguAPIError('Failed to get project') from e
        
        result = json.loads(response.content.decode('utf-8'))
        if response.status_code == 200 and len(result["results"]) > 0:
            json_project = result["results"][0]
            try:
                return Project(**json_project)
            except ValidationError as e:
                raise PinguAPIError("Invalid project data received from.server") from e
            
    