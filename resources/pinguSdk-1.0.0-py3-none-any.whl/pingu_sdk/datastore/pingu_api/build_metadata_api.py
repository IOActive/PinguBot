import json
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.data_constants import BuildState
from pingu_sdk.datastore.models.build_metadata import BuildMetadata
from pingu_sdk.datastore.models.crash import Crash
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs


class BuildMetadataApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'buildmetadata'

    def get_build_state(self, job_id: UUID, crash_revision: int) -> BuildState:
        try:
            params = {"job_id": str(job_id), "revision": crash_revision}
            response = self.make_request(method='GET', path=self.path, params=params)
            try:
                if response.status_code == 200:
                    json_BuildMetadatas = json.loads(response.content.decode('utf-8'))['results']
                    builds = [BuildMetadata(**json_BuildMetadata) for json_BuildMetadata in json_BuildMetadatas]
                    for build in builds:
                        if not build:
                            return BuildState.UNMARKED

                        if build.bad_build:
                            return BuildState.BAD
                        
                        return BuildState.GOOD
                    
                    return BuildState.UNMARKED
                else:
                    return BuildState.UNMARKED
            except ValidationError as e:
                logs.log_error(e)
                return BuildState.UNMARKED
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add trial') 
        
    def add_build_metadata(self, buildMetadata: BuildMetadata):
        """Adds metadata for a build"""
        try:
            payload = json.loads(buildMetadata.model_dump_json(exclude={'id'}))
            self.make_request(method='POST', path=self.path, json=payload)
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add build metadata') 
 
