from datetime import datetime
import json
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.bot import Bot
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
# ------------------------------------------------------------------------------
# Bot API Implementaion
# ------------------------------------------------------------------------------

class BotApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "bot"

    def register_bot(self, bot_name: str, last_beat_time: datetime, platform: str):
        payload = {'name': bot_name,
            'last_beat_time': last_beat_time,
            'platform': platform,
        }
        try:
            self.make_request(method='POST', path=self.path, json=payload)
        except Exception as e:
            raise PinguAPIError('Failed to register bot') from e

    def get_bot(self, bot_name: str) -> Bot:
        try:
            params= {"name": bot_name}
            response = self.make_request(method='GET', path=self.path, params=params)
        except Exception as e:
            raise PinguAPIError('Failed to get bot') from e
        
        result = json.loads(response.content.decode('utf-8'))
        if response.status_code == 200 and len(result["results"]) > 0:
            json_bot = result["results"][0]
            try:
                return Bot(**json_bot)
            except ValidationError as e:
                raise PinguAPIError("Invalid bot data received from.server") from e
            
    def update_bot(self, payload, bot_id: UUID):        
        try:
            self.make_request(method='PATCH', path=f'{self.path}/{str(bot_id)}', json=payload)
        except Exception as e:
            raise PinguAPIError("Failed to update bot") from e
    