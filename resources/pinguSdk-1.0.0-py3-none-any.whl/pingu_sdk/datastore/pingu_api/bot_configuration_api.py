

import json
from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pydantic import ValidationError
from pingu_sdk.datastore.models import BotConfiguration
import yaml
import re

class BotConfigurationApi(PinguApi):
    
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "botconfig"
        
    def get_configuration(self, bot_id: UUID):
        try:
            params= {"bot_id": str(bot_id)}
            response = self.make_request(method='GET', path=self.path, params=params)
            content = response.content.decode('utf-8').replace("\n", "\\n")
            result = json.loads(content)
            if response.status_code == 200 and len(result["results"]) > 0:
                json_bot_configuration = result["results"][0]
                try:
                    return BotConfiguration(**json_bot_configuration)
                except ValidationError as e:
                    raise PinguAPIError("Invalid bot data received from.server") from e
            
        except Exception as e:
            raise PinguAPIError('Failed to get bot configuration') from e