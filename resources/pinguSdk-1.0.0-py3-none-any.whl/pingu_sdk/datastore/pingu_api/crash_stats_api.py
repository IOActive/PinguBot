import json
from pingu_sdk.datastore.models.crash_stats import CrashStats
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs


class CrashStatsApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'crash_stats'
        
    def add_crash_stats(self, crash_stats: CrashStats):
        try:
            payload = json.loads(crash_stats.model_dump_json(exclude={'id'}))
            response = self.make_request(method='POST', path=self.path, json=payload)
            if response.status_code == 201:
                logs.log(f'Crash added')
            else:
                raise PinguAPIError(f'Failed to add crash with status code {response.status_code}')
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add crash') 