
import json
from uuid import UUID
from pingu_sdk.datastore.models.fuzz_target import FuzzTarget
from pingu_sdk.datastore.pingu_api.pingu_api import PinguApi


class FuzzTargetApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'fuzztarget'
    
    def get_fuzz_target_by_id(self, id: UUID) -> FuzzTarget:
        try:
            params = {"id": str(id)}
            response = self.make_request(method='GET', path=f'{self.path}', params=params)
            fuzztarget_json = json.loads(response.content.decode('utf-8'))
            if  len(fuzztarget_json['results']) > 0:
                fuzztarget_json = fuzztarget_json['results'][0]
                return FuzzTarget(**fuzztarget_json)
        except Exception as e:
            print(e)

    def get_fuzz_target_by_keyName(self, fuzzer_id: UUID, binary: str) -> FuzzTarget:
        try:
            params = {"fuzzer_id": str(fuzzer_id), "binary": binary}
            response = self.make_request(method='GET', path=f'{self.path}', params=params)
            fuzztarget_json = json.loads(response.content.decode('utf-8'))
            if  len(fuzztarget_json['results']) > 0:
                fuzztarget_json = fuzztarget_json['results'][0]
                return FuzzTarget(**fuzztarget_json)
        except Exception as e:
            print(e)

    def add_fuzz_target(self, fuzzTarget: FuzzTarget) -> None:
        try:
            payload =json.loads(fuzzTarget.model_dump_json(exclude={'id'}))
            self.make_request(method='POST', path=self.path, json=payload)
        except Exception as e:
            print(e)
