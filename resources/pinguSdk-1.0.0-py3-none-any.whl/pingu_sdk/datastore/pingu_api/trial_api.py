import json
from typing import List
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.trial import Trial
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs

class TrialApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "trial"
    
    def get_trial_by_id(self, id:UUID) -> Trial:
        try:
            params = {"id": str(id)}
            response = self.make_request(method='GET', path=self.path, params=params)
            trial_json = json.loads(response.content.decode('utf-8'))
            if  len(trial_json['results']) > 0:
                trial_json = trial_json['results'][0]
                return Trial(**trial_json)
        except Exception as e:
            raise PinguAPIError('Failed to get trial') 
        
    def get_trials_by_name(self, name:str) -> List[Trial]:
        try:
            response = self.make_request(method='GET', path=self.path, params={"name": name})
            if response.status_code == 200:
                json_trials = json.loads(response.content.decode('utf-8'))['results']
                trials = []
                try:
                    for json_trial in json_trials:
                        trials.append(Trial(**json_trial))
                    return trials
                except ValidationError as e:
                    logs.log_error(e)
                    raise ValidationError
        except Exception as e:
            raise PinguAPIError('Failed to get trial') 
    
    def add_trial(self, trial:Trial) -> None:
        try:
            payload = json.loads(trial.model_dump_json(exclude={'id'}))
            self.make_request(method='POST', path=self.path, json=payload)
        except Exception as e:
            raise PinguAPIError('Failed to add trial') 