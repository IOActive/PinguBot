import json

from pydantic import ValidationError
from pingu_sdk.datastore.models.job_template import JobTemplate
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi


class JobTemplateApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "jobtemplate"
        
    def get_jobtemplate(self, template_name: str) -> JobTemplate:
        try:
            params = {"name": template_name}
            response = self.make_request(method="GET", path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if len(result['results']) > 0:
                json_job = result['results'][0]
                try:
                    return JobTemplate(**json_job)
                except ValidationError as e:
                    raise PinguAPIError("Invalid response from.server", e.json())
            else:
                raise PinguAPIError("No job template found with that name")
        except Exception as e:
            raise PinguAPIError(str(e))