from typing import List
from uuid import UUID
from pydantic import ValidationError
from pingu_sdk.datastore.models.fuzz_target_job import FuzzTargetJob
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
import json

class FuzzTargetJobApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "fuzztargetjob"

    def get_fuzz_target_jobs_by_job(self, job_id: UUID) -> list[FuzzTargetJob]:
        try:
            params = {"job_id": str(job_id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            json_fuzzTargetJobs = json.loads(response.content.decode('utf-8'))['results']
            try:
                fuzzTargetJobs = [FuzzTargetJob(**json_fuzzTargetJob) for json_fuzzTargetJob in json_fuzzTargetJobs]
                return fuzzTargetJobs
            except ValidationError as e:
                raise ValueError("Invalid response from.server")
        except Exception as e:
            raise PinguAPIError('Failed to get fuzz target jobs') 
        
    def get_fuzz_target_jobs_by_job_fuzztarget(self, job_id: UUID, fuzz_target_id: UUID) -> List[FuzzTargetJob]:
        try:
            params = {"job_id": str(job_id), "fuzz_target_id": str(fuzz_target_id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            json_fuzzTargetJobs = json.loads(response.content.decode('utf-8'))['results']
            try:
                fuzzTargetJobs = [FuzzTargetJob(**json_fuzzTargetJob) for json_fuzzTargetJob in json_fuzzTargetJobs]
                return fuzzTargetJobs
            except ValidationError as e:
                raise ValueError("Invalid response from.server")
        except Exception as e:
            raise PinguAPIError('Failed to get fuzz target jobs') 
        
    def get_fuzz_target_jobs_by_engine(self, fuzzer_id: UUID) -> List[FuzzTargetJob]:
        try:
            params = {"fuzzer_id": str(fuzzer_id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            json_fuzzTargetJobs = json.loads(response.content.decode('utf-8'))['results']
            try:
                fuzzTargetJobs = [FuzzTargetJob(**json_fuzzTargetJob) for json_fuzzTargetJob in json_fuzzTargetJobs]
                return fuzzTargetJobs
            except ValidationError as e:
                raise ValueError("Invalid response from.server")
        except Exception as e:
            raise PinguAPIError('Failed to get fuzz target job by engine') 
        
    def add_fuzz_target_job(self, fuzz_target_job: FuzzTargetJob) -> None:
        try:
            payload = json.loads(fuzz_target_job.model_dump_json(exclude={'id'}))
            self.make_request(method="POST", path=self.path, json=payload)
        except Exception as e:
            raise PinguAPIError('Failed to add fuzz target job') 
    