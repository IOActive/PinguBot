import json
from typing import List

from pydantic import ValidationError
from pingu_sdk.datastore.models.fuzzer import Fuzzer
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs

class FuzzerApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "fuzzer"

    def get_fuzzer(self, name) -> Fuzzer:
        try:
            params = {'name': str(name)}
            response = self.make_request(method="GET", path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if len(result['results']) > 0:
                json_fuzzer = result['results'][0]
                try:
                    return Fuzzer(**json_fuzzer)
                except ValidationError as e:
                    raise PinguAPIError("Invalid response from.server", e.json())
            else:
                raise PinguAPIError("No fuzzer found with that name")
        except Exception as e:
            raise PinguAPIError(str(e))
    
    def get_fuzzer_by_id(self, id) -> Fuzzer:
        try:
            params = {'id': str(id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if len(result['results']) > 0:
                json_fuzzer = result['results'][0]
                try:
                    return Fuzzer(**json_fuzzer)
                except ValidationError as e:
                    raise PinguAPIError("Invalid response from.server", e.json())
            else:
                raise PinguAPIError("No fuzzer found with that id")
        except Exception as e:
            raise PinguAPIError(str(e))
        
    def update_fuzzer(self, fuzzer: Fuzzer):
        try:
            payload = json.loads(fuzzer.model_dump_json(exclude={'id'}))
            self.make_request(method="PATCH", path=f"{self.path}/{str(fuzzer.id)}", json=payload)
        except Exception as e:
            raise PinguAPIError(str(e))
        
    def download_fuzzer(self, id) -> bytes:
        try:
            response = self.make_request(method='GET', path=f"{self.path}/{id}/download")
            zip_bytes = response.content
            return zip_bytes
        except Exception as e:
            raise PinguAPIError('Failed to download corpus') from e