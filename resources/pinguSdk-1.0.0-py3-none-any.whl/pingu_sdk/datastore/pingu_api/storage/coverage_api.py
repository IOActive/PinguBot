from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi

class CoverageApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/coverage"

    def upload_coverage(self, project_id: UUID, fuzz_target_id: UUID, files: list):
        try:
            payload = {
                'project_id': str(project_id),
                'fuzz_target_id': str(fuzz_target_id)
            }
            files_data = [
                ('files', (file['name'], file['content'], file['content_type']))
                for file in files
            ]
            self.make_request(method='POST', path=f"{self.path}/upload", data=payload, files=files_data)
        except Exception as e:
            raise PinguAPIError('Failed to upload coverage') from e
