from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi

class StatsApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/stats"

    def upload_stats(self, project_id: UUID, fuzz_target_id: UUID, job_id: UUID, kind: str, files: list):
        try:
            payload = {
                'project_id': str(project_id),
                'fuzz_target_id': str(fuzz_target_id),
                'job_id': str(job_id),
                'kind': kind
            }
            files_data = [
                ('files', (file['name'], file['content'], file['content_type']))
                for file in files
            ]
            self.make_request(method='POST', path=f"{self.path}/upload", data=payload, files=files_data)
        except Exception as e:
            raise PinguAPIError('Failed to upload stats') from e
