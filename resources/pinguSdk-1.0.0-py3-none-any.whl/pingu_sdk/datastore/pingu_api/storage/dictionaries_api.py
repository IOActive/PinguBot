from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi

class DictionariesApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/dictionaries"

    def upload_dictionary(self, project_id: UUID, fuzztarget_id: UUID, dictionary_file: dict):
        try:
            payload = {
                'project_id': str(project_id),
                'fuzztarget_id': str(fuzztarget_id)
            }
            files_data = [
                ('dictionary', (dictionary_file['name'], dictionary_file['content'], dictionary_file['content_type']))
            ]
            self.make_request(method='POST', path=f"{self.path}/upload", data=payload, files=files_data)
        except Exception as e:
            raise PinguAPIError('Failed to upload dictionary') from e

    def download_dictionary(self, project_id: UUID, fuzztarget_id: UUID, dictionary_name: str) -> bytes:
        try:
            payload = {
                'project_id': str(project_id),
                'fuzztarget_id': str(fuzztarget_id),
                'dictionary_name': dictionary_name
            }
            response = self.make_request(method='GET', path=f"{self.path}/download", params=payload)
            return response.content
        except Exception as e:
            raise PinguAPIError('Failed to download dictionary') from e

    def dictionary_exists(self, project_id: UUID, fuzztarget_id: UUID, dictionary_name: str) -> bool:
        try:
            payload = {
                'project_id': str(project_id),
                'fuzztarget_id': str(fuzztarget_id),
                'dictionary_name': dictionary_name
            }
            response = self.make_request(method='GET', path=f"{self.path}/exists", params=payload)
            return response.json().get('status') == 'exists'
        except Exception as e:
            raise PinguAPIError('Failed to check if dictionary exists') from e

    def list_dictionaries(self, project_id: UUID, fuzztarget_id: UUID) -> list:
        try:
            payload = {
                'project_id': str(project_id),
                'fuzztarget_id': str(fuzztarget_id)
            }
            response = self.make_request(method='GET', path=f"{self.path}/list", params=payload)
            return response.json().get('dictionaries')
        except Exception as e:
            raise PinguAPIError('Failed to list dictionaries') from e
