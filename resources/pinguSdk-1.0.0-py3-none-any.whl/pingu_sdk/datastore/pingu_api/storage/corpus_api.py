from enum import Enum
from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi


class CorpusTypes(Enum):
    CORPUS = "corpus"
    BACKUP = "backup"
    SHARED = "shared"
    QUARANTINE = "quarantine"
    
class CorpusApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/corpus"

    def upload_corpus(self, project_id: UUID, fuzz_target_id: UUID, files: list, kind: CorpusTypes):
        try:
            payload = {
                'project_id': str(project_id),
                'fuzz_target_id': str(fuzz_target_id),
                'kind': kind.value,
            }
            files_data = [
                ('files', (file['name'], file['content'], file['content_type']))
                for file in files
            ]
            self.make_request(method='POST', path=f"{self.path}/upload", data=payload, files=files_data)
        except Exception as e:
            raise PinguAPIError('Failed to upload corpus') from e

    def download_corpus(self, project_id: UUID, fuzz_target_id: UUID, kind: CorpusTypes = CorpusTypes.CORPUS) -> bytes:
        try:
            payload = {
                'project_id': str(project_id),
                'fuzz_target_id': str(fuzz_target_id),
                'kind': kind.value
            }
            response = self.make_request(method='GET', path=f"{self.path}/download", params=payload)
            zip_bytes = response.content
            return zip_bytes
        except Exception as e:
            raise PinguAPIError('Failed to download corpus') from e
