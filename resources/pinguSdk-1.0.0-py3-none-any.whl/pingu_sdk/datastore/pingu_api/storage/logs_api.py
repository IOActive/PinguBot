from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi

class LogsApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/logs"

    def upload_logs(self, project_id: UUID, job_id: UUID, log_type: str, files: list, task_id: UUID = "", fuzzer_id: UUID = ""):
        try:
            # Prepare the payload as form data (not JSON)
            payload = {
                'project_id': str(project_id),
                'job_id': str(job_id),
                'log_type': log_type,
                'task_id': str(task_id),
                'fuzzer_id': str(fuzzer_id)
            }
            
            # Prepare files for upload
            files_data = [
                ('files', (file['name'], file['content'], file['content_type']))
                for file in files
            ]
            
            # Combine payload and files into a single multipart request
            response = self.make_request(
                method='POST',
                path=f"{self.path}/upload",
                data=payload,  # Send as form fields, not JSON
                files=files_data
            )
            return response
        except Exception as e:
            raise PinguAPIError('Failed to upload logs') from e


    def download_logs(self, project_id: UUID, job_id: UUID, log_type: str, task_id: str = "", fuzzer_id: UUID = "", date: UUID = "") -> bytes:
        try:
            payload = {
                'project_id': str(project_id),
                'job_id': str(job_id),
                'log_type': log_type,
                'task_id': str(task_id),
                'fuzzer_id': str(fuzzer_id),
                'date': date
            }
            response = self.make_request(method='GET', path=f"{self.path}/download", params=payload)
            return response.content
        except Exception as e:
            raise PinguAPIError('Failed to download logs') from e
