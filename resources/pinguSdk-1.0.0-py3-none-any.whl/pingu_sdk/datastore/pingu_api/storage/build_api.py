from enum import Enum
from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi


class BuildType(Enum):
        RELEASE = 'release'
        SYM_RELEASE = 'sym_release'
        SYM_DEBUG = 'sym_debug'
        STABLE = 'stable'
        BETA = 'beta'
        NA = 'na'
class BuildApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/builds"

    def get_build_size(self, project_id: UUID, build_type: BuildType, file_path: str = "") -> int:
        try:
            payload = {
                'project_id': str(project_id),
                'build_type': build_type.value,
                'file_path': file_path
            }
            response = self.make_request(method='GET', path=f"{self.path}/size", params=payload)
            return response.json().get('build_size')
        except Exception as e:
            raise PinguAPIError('Failed to get build size') from e

    def download_build(self, project_id: UUID, build_type: BuildType, file_path: str = "") -> bytes:
        try:
            payload = {
                'project_id': str(project_id),
                'build_type': build_type.value,
                'file_path': file_path
            }
            response = self.make_request(method='POST', path=f"{self.path}/download", data=payload)
            return response.content
        except Exception as e:
            raise PinguAPIError('Failed to download build') from e

    def get_build_list(self, project_id: UUID, build_type: BuildType) -> list:
        try:
            payload = {
                'project_id': str(project_id),
                'build_type': build_type.value
            }
            response = self.make_request(method='GET', path=f"{self.path}/list", params=payload)
            return response.json().get('build_list')
        except Exception as e:
            raise PinguAPIError('Failed to get build list') from e
