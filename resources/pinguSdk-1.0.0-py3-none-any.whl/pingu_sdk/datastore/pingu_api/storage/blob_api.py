from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi


class BlobsApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "storage/blobs"
        
    def upload_blob(self, project_id: UUID, blob_name: str, blob_data: bytes):
        try:
            payload = {'project_id': str(project_id), 'key': blob_name}
            files = {'blob': (blob_name, blob_data)}
            self.make_request(method='POST', path=f"{self.path}/upload", data=payload, files=files)
        except Exception as e:
            raise PinguAPIError('Failed to upload blob') from e
        
    def download_blob(self, project_id: UUID, blob_name: str) -> bytes:
        try:
            payload = {'project_id': project_id, 'key': blob_name}
            response = self.make_request(method='GET', path=f"{self.path}/download", params=payload)
            return response.content
        except Exception as e:
            raise PinguAPIError('Failed to download blob') from e
        
    def read_blob(self, project_id: UUID, blob_name: str) -> str:
        try:
            payload = {'project_id': project_id, 'key': blob_name}
            response = self.make_request(method='GET', path=f"{self.path}/read", params=payload)
                    # Use iter_content to handle streaming content
            return b''.join(response.streaming_content)
        except Exception as e:
            raise PinguAPIError('Failed to read blob') from e
        
    def delete_blob(self, project_id: UUID, blob_name: str):
        try:
            payload = {'project_id': project_id, 'key': blob_name}
            response = self.make_request(method='DELETE', path=f"{self.path}/delete", params=payload)
                    # Use iter_content to handle streaming content
            return b''.join(response.streaming_content)
        except Exception as e:
            raise PinguAPIError('Failed to read blob') from e
            