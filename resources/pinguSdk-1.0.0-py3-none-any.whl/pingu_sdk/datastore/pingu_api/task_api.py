from datetime import datetime
import json
from typing import Union
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.datastore.models.task import Task
# ------------------------------------------------------------------------------
# Task API Implementaion
# ------------------------------------------------------------------------------

class TaskApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "task"

    def get_task_status(self, task_name: str) -> json:
        try:
            params = {'name': task_name}
            response = self.make_request(method='GET', path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if len(result["results"]) > 0:
                return result["results"][0]['status']
            else:
                raise PinguAPIError('Task not found')
        except Exception as e:
            raise PinguAPIError('Failed to get task status') from e

    def get_queue_task(self, platform: str) -> Task:
        try:
            params = {'platform': platform}
            response = self.make_request(method='GET', path=self.path, params=params)
            json_task = json.loads(response.content.decode('utf-8'))
            return json_task
        except Exception as e:
            raise PinguAPIError('Failed to get task') from e

    def add_task(self, command: str, argument: Union[str,UUID], job_id: UUID, queue: str) -> None:
        platform = queue.split("-")[1].title()
        payload = {
            'job_id': str(job_id),
            'platform': platform,
            'command': command,
            'argument': str(argument),
            }
        try:
            self.make_request(method='POST', path=self.path, json=payload)
        except Exception as e:
            raise PinguAPIError('Failed to add task') from e
        
    def get_task(self, task_id: UUID):
        try:
            params = {'id': str(task_id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if response.status_code == 200 and len(result["results"]) > 0:
                json_task = result["results"][0]
                try:
                    return Task(**json_task)
                except ValidationError as e:
                    raise PinguAPIError("Invalid Task data received from.server") from e
        except Exception as e:
            raise PinguAPIError('Failed to get task') from e
        
    def update_task(self, task_id, payload):
        try:
            self.make_request(method='PATCH', path=f'{self.path}/{str(task_id)}', json=payload)
        except Exception as e:
            raise PinguAPIError('Failed to update task') from e

   