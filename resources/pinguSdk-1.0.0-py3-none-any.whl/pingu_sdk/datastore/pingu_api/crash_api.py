import json
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.crash import Crash
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs


class CrashApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'crash'

    def get_crash_by_testcase(self, testcase_id: UUID) -> Crash:
        try:
            params = {'testcase_id': str(testcase_id)}
            response = self.make_request(method='GET', path=self.path, params=params)
            try:
                result = json.loads(response.content.decode('utf-8'))
                if response.status_code == 200 and len(result['results']) > 0:
                    json_crash = result['results'][0]
                    return Crash(**json_crash)
            except ValidationError as e:
                logs.log_error(e)          
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add trial') 
        
    def add_crash(self, crash: Crash):
        try:
            payload = json.loads(crash.model_dump_json(exclude={'id'}))
            response = self.make_request(method='POST', path=self.path, json=payload)
            if response.status_code == 201:
                logs.log(f'Crash added')
                crash_id = json.loads(response.content)['id']
                return crash_id
            else:
                raise PinguAPIError(f'Failed to add crash with status code {response.status_code}')
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add crash') 

    def update_crash(self, crash: Crash):
        try:
            payload = json.loads(crash.model_dump_json(exclude={'id'}))
            response = self.make_request(method='PATCH', path=f"{self.path}/{crash.id}", json=payload)
            if response.status_code == 200:
                logs.log(f'Crash updated')
            else:
                raise PinguAPIError(f'Failed to update crash with status code {response.status_code}')
        except PinguAPIError as e:
            raise PinguAPIError('Failed to update crash') 
