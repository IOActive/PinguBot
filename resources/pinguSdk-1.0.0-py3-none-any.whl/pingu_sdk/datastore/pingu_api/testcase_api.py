import json
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.testcase import Testcase
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs


class TestcaseApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "testcase"

    def find_testcase(self, project_name: str, crash_type: str, crash_state: str, security_flag: bool, testcase_to_exclude=None) -> Testcase:
        try:
            if security_flag:
                command = {
                    "job_id__project": project_name,
                    "crash_testcase__crash_type": crash_type,
                    "crash_testcase__crash_state": crash_state,
                    "crash_testcase__security_flag": ""
                }
            else:
                command = {
                    "job_id__project": project_name,
                    "crash_testcase__crash_type": crash_type,
                    "crash_testcase__crash_state": crash_state
                }
            
            response = self.make_request(method='GET', path=self.path, params=command)
            try:
                result = json.loads(response.content.decode('utf-8'))
                if len(result['results']) > 0:
                    if testcase_to_exclude:
                        for result in result['results']:
                            current_testcase =  Testcase(**result)
                            if current_testcase != testcase_to_exclude:
                                return current_testcase
                    else:
                        json_testcase = result['results'][0]
                        logs.log("Main Testcase Identified")
                    return Testcase(**json_testcase)
                else:
                    logs.log("Testcase Not Found")
            except ValidationError as e:
                raise ValidationError(f"Validation error: {e}") from e
        except Exception as e:
            raise PinguAPIError('Failed to add trial') from e
        
    def get_testcase_by_id(self, id: UUID) -> Testcase:
        """Get a testcase by its ID."""
        try:
            params = {"id": str(id)}
            response = self.make_request(method='GET', path=self.path, params=params)
            try:
                result = json.loads(response.content.decode('utf-8'))
                if len(result['results']) > 0:
                    json_testcase = result['results'][0]
                    logs.log("Main Testcase Identified")
                    return Testcase(**json_testcase)
                else:
                    logs.log('Failed to get testcase')
            except ValidationError as e:
                raise ValidationError('Invalid JSON response server') from e
        except Exception as e:
            raise PinguAPIError('Failed to get testcase') 
        
    def add_testcase(self, testcase: Testcase):
        try:
            payload = json.loads(testcase.model_dump_json(exclude={'id'}))
            response = self.make_request(method='POST', path=self.path, json=payload)
            if response.status_code == 201:
                #must return testcase id
                testcase_id = json.loads(response.text)['id']
                logs.log("Testcase added successfully")
                return testcase_id
            else:
                raise PinguAPIError(f"Failed to add testcase with status code {response.status_code}")
        except Exception as e:
            raise PinguAPIError('Failed to add testcase') from e
        
    def update_testcase(self, testcase: Testcase):
        try:
            payload = json.loads(testcase.model_dump_json(exclude={'id'}))
            response = self.make_request(method='PATCH', path=f'{self.path}/{testcase.id}', json=payload)
            if response.status_code == 200:
                logs.log("Testcase updated successfully")
            else:
                raise PinguAPIError(f"Failed to update testcase with status code {response.status_code}")
        except Exception as e:
            raise PinguAPIError('Failed to update testcase') 


