import json
from typing import List
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.job import Job
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs

class JobApi(PinguApi):

    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = "job"
        
    def get_job(self, job_id: UUID):
        try:
            params = {"id": str(job_id)}
            response = self.make_request(method="GET", path=self.path, params=params)
            result = json.loads(response.content.decode('utf-8'))
            if len(result['results']) > 0:
                json_job = result['results'][0]
                try:
                    return Job(**json_job)
                except ValidationError as e:
                    raise PinguAPIError("Invalid response from.server", e.json())
            else:
                raise PinguAPIError("No job found with that id")
        except Exception as e:
            raise PinguAPIError(str(e))
    
    def get_jobs(self) -> List[Job]:
        try:
            response = self.make_request(method="GET", path=self.path)
            jobs = []
            if response.status_code == 200:
                json_jobs = json.loads(response.content.decode('utf-8'))['results']
                try:
                    for json_job in json_jobs:
                        jobs.append(Job(**json_job))
                    return jobs
                except ValidationError as e:
                    logs.log_error(e)
                    raise ValidationError
        except Exception as e:
            raise PinguAPIError(str(e)) 




   