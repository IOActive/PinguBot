import json

from pydantic import ValidationError
from pingu_sdk.datastore.models.crash import Crash
from pingu_sdk.datastore.models.data_bundle import DataBundle
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs


class DataBundleApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'databundle'
    
    def get_data_bundle(self, bundle_name) -> DataBundle:
        try:
            params = {'name': bundle_name}
            response = self.make_request(method='GET', path=self.path, params=params)
            try:
                result = json.loads(response.content.decode('utf-8'))
                if response.status_code == 200 and len(result['results']) > 0:
                    json_data_bundle = result['results'][0]
                    data_bundle = DataBundle(**json_data_bundle)
                    return data_bundle
            except ValidationError as e:
                logs.log_error('Invalid response from server', error=e)
                raise PinguAPIError("Invalid response from server") from e
        except PinguAPIError as e:
            logs.log_error('Failed to get data bundle from pingu api', error=str(e))
            raise PinguAPIError('Failed to add trial') 
