import requests
from requests import Response


class PinguAPIError(Exception):
    pass

class PinguApi():
    def __init__(self, host, auth_token) -> None:
        self.host = host
        self.authToken = auth_token
        self.headers = {'Authorization': f'Token {self.authToken}'}
        self.baseUrl = f"{self.host}/api/"

    def ping(self) -> bool:
        print("Pinging the API...")
        response = requests.get(f"{self.baseUrl}/ping", headers=self.headers)
        if response.status_code != 200:
            raise PinguAPIError(f"Failed to ping the API. Status code: {response.status_code}")
        else:
            print("API is up and running!")
            return True
        
    def make_request(self, method, path, **kwargs) -> Response:
        # Ensure headers don’t override Content-Type to application/json
        headers = self.headers.copy()  # Copy to avoid modifying the original
        if 'files' in kwargs:
            headers.pop('Content-Type', None)  # Let requests set multipart/form-data
        
        # Make the HTTP request
        response = requests.request(
            method=method,
            url=f'{self.baseUrl}{path}/',
            headers=headers,
            **kwargs
        )
        
        # Raise an exception if the response was not successful
        response.raise_for_status()
        
        return response