import json
from typing import List
from uuid import UUID

from pydantic import ValidationError
from pingu_sdk.datastore.models.testcase_variant import TestcaseVariant
from pingu_sdk.datastore.pingu_api.pingu_api import PinguAPIError, PinguApi
from pingu_sdk.metrics import logs

class TestcaseVariantApi(PinguApi):
    def __init__(self, host: str, auth_token: str) -> None:
        super().__init__(host, auth_token)
        self.path = 'testcasevariant'

    def get_testcase_variant(self, testcase_id: UUID, job_id: UUID) -> TestcaseVariant:
        try:
            params = {'testcase_id': str(testcase_id), 'job_id': str(job_id)}
            response = self.make_request(method='GET', path=self.path, params=params)
            try:
                result = json.loads(response.content.decode('utf-8'))
                if response.status_code == 200 and len(result['results']) > 0:
                    json_testcase_variant = result['results'][0]
                    return TestcaseVariant(**json_testcase_variant)
            except ValidationError as e:
                logs.log_error(e)
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add trial') 
    
    def add_testcase_variant(self, testcase_variant: TestcaseVariant):
        try:
            payload = json.loads(testcase_variant.model_dump_json(exclude={'id'}))
            response = self.make_request(method='POST', path=self.path, json=payload)
            if response.status_code == 201:
                logs.log(f'Testcase variant {testcase_variant.id} added successfully')
            else:
                raise PinguAPIError('Failed to add testcase variant')
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add trial') 
        
    def update_testcase_variant(self, testcase_variant: TestcaseVariant):
        try:
            payload = json.loads(testcase_variant.model_dump_json(exclude={'id'}))
            response = self.make_request(method='PATCH', path=self.path, json=payload)
            if response.status_code == 200:
                logs.log(f'Testcase variant {testcase_variant.id} updated successfully')
            else:
                raise PinguAPIError('Failed to update testcase variant')
        except PinguAPIError as e:
            raise PinguAPIError('Failed to add trial') 