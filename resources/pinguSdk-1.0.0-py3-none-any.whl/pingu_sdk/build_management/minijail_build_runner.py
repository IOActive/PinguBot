from pingu_sdk.system import minijail, new_process


class MinijailBuildRunner(new_process.UnicodeProcessRunnerMixin,
                          minijail.MinijailProcessRunner):
    """Minijail Builder runner."""

    def __init__(self, executable_path, chroot, default_args=None):
        """Inits the LibFuzzerRunner.
        Args:
          executable_path: Path to the fuzzer executable.
          chroot: A MinijailChroot.
          default_args: Default arguments to always pass to the fuzzer.
        """
        super().__init__(
            executable_path=executable_path,
            chroot=chroot,
            default_args=default_args)
        self.SIGTERM_WAIT_TIME = 10.0

    def build(self):
        self.run_and_wait(terminate_before_kill=True,
                          terminate_wait_time=self.SIGTERM_WAIT_TIME, timeout=1000)

