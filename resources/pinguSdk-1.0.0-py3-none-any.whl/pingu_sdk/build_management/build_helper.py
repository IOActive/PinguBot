
import re
from uuid import UUID
from pingu_sdk.build_management import revisions
from pingu_sdk.build_management.build_managers.android_emulator_build import AndroidEmulatorBuild
from pingu_sdk.build_management.build_managers.custom_build import CustomBuild
from pingu_sdk.build_management.build_managers.cuttlefish_kernel_build import CuttlefishKernelBuild
from pingu_sdk.build_management.build_managers.production_build import ProductionBuild
from pingu_sdk.build_management.build_managers.regular_build import RegularBuild
from pingu_sdk.build_management.build_managers.symbolized_build import SymbolizedBuild
from pingu_sdk.build_management.build_managers.system_build import SystemBuild
from pingu_sdk.build_management.build_managers.build_utils import BuildManagerException, build_buckets_storages, full_fuzz_target_path, get_base_build_dir, get_bucket_path, get_build_packages_list, get_latest_revision, get_targets_list, set_random_fuzz_target_for_fuzzing_if_needed
from pingu_sdk.config.project_config import ProjectConfig
from pingu_sdk.datastore import data_constants
from pingu_sdk.datastore.pingu_api.job_api import JobApi
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment
from pingu_sdk.datastore.pingu_api.storage.build_api import BuildType

DEFAULT_BUILD_BUCKET_PATH_ENV_VARS = (
    'RELEASE_BUILD_BUCKET_PATH',
    'SYM_RELEASE_BUILD_BUCKET_PATH',
    'SYM_DEBUG_BUILD_BUCKET_PATH',
)


class BuildHelper():
    """Helper class for setting up builds."""
    def __init__(self, job_id: UUID = None, bucket_path: str = None, build_prefix: str = '', target_weights: dict = {}, revision: int = 0):
        self.build_prefix = build_prefix
        self.target_weights = target_weights
        self.revision = revision
        self.bucket_path = bucket_path
        
        if job_id:
            self.job_id = job_id
            self.job = get_api_client().job_api.get_job(job_id=job_id)
            self.project = get_api_client().project_api.get_project_by_id(self.job.project_id)
            environment.set_value('JOB_ID', self.job.id)

    def _setup_split_targets_build(self, build_type: BuildType):
        """Set up targets build."""
        targets_list = get_targets_list(self.job.id, build_type)
        if not targets_list:
            raise BuildManagerException(
                'No targets found in targets.list (path=%s).' % self.job.name)

        fuzz_target_package = set_random_fuzz_target_for_fuzzing_if_needed(targets_list, self.target_weights)
        if not fuzz_target_package:
            raise BuildManagerException(
                'Failed to choose a fuzz target (job=%s).' % self.job.name)

        if self.revision == 0:
            self.revision = get_latest_revision([(build_type, fuzz_target_package)], self.project.id)

        self.bucket_path = fuzz_target_package
        
        return self.setup_regular_build(build_type)

    def setup_trunk_build(self, build_storages):
        """Sets up latest trunk build."""
        latest_revision = get_latest_revision(build_storages, self.project.id)
        if latest_revision is None:
            logs.log_error('Unable to find a matching revision.')
            return None
        
        build_type, self.bucket_path = build_storages[0]
        self.revision = latest_revision
        build = self.setup_regular_build(build_type)
        if not build:
            logs.log_error('Failed to set up a build.')
            return None

        return build

    def setup_regular_build(self, build_type):
        """Sets up build with a particular revision."""
        if not build_type:
            build_type = BuildType.RELEASE
            
        if not self.bucket_path:
            self.bucket_path = f"{environment.get_value('RELEASE_BUILD_BUCKET_PATH')}"

            
        build_packages = get_build_packages_list(
            project_id=self.project.id,
            kind=build_type,
            bucket_path=self.bucket_path
        )
        
        if not build_packages:
            logs.log_error('Error getting build packages for job %s.' % self.job.id)
            return None
        
        build_package = revisions.find_build_packge(self.bucket_path, build_packages, self.revision)
        
        if not build_package:
            logs.log_error('Error getting build package for job %s (r%d).' % (self.job.id, self.revision))

            return None
        
        bucket_name = ProjectConfig().get(f'build.{build_type.value}.bucket')
        
        base_build_dir = get_base_build_dir(f"{bucket_name}/{self.bucket_path}", self.job.id)

        build_class = RegularBuild

        if environment.is_android_emulator():
            build_class = AndroidEmulatorBuild
        elif (environment.is_android_cuttlefish() and
            environment.is_kernel_fuzzer_job()):
            build_class = CuttlefishKernelBuild

        build = build_class(
            base_build_dir=base_build_dir,
            revision=self.revision,
            build_path=build_package,
            project_id=self.job.project_id,
            build_type=build_type,
            target_weights=self.target_weights,
            build_prefix=self.build_prefix)
        
        if build.setup():
            return build
        return None

    def setup_symbolized_builds(self):
        """Set up symbolized release and debug build."""
        
        sym_release_build_path = environment.get_value(
            'SYM_RELEASE_BUILD_BUCKET_PATH')
        sym_debug_build_path = environment.get_value(
            'SYM_DEBUG_BUILD_BUCKET_PATH')

        sym_release_build_packages = get_build_packages_list(
            self.project.id, BuildType.SYM_RELEASE, sym_release_build_path)
        
        sym_debug_build_packages = get_build_packages_list(
            self.project.id, BuildType.SYM_DEBUG, sym_debug_build_path)

        # We should at least have a symbolized debug or release build.
        if not sym_release_build_packages and not sym_debug_build_packages:
            logs.log_error(
                'Error getting list of symbolized build urls from storage.(%s, %s).' %
                (sym_release_build_path, sym_debug_build_path))
            return None

        sym_release_build_path = revisions.find_build_packge(
            sym_release_build_path, sym_release_build_packages, self.revision)
        
        sym_debug_build_path = revisions.find_build_packge(sym_debug_build_path,
                                                    sym_debug_build_packages, self.revision)

        
        bucket_name = ProjectConfig().get(f'build.sym-release.bucket')
        
        base_build_dir = get_base_build_dir(f"{bucket_name}/{sym_release_build_path}", self.job.id)

        build_class = SymbolizedBuild

        build = build_class(
            base_build_dir=base_build_dir,
            revision=self.revision,
            release_build_path=sym_release_build_path,
            debug_build_path=sym_debug_build_path,
            project_id=self.project.id
        )
        
        if build.setup():
            return build

        return None

    def setup_custom_binary(self):
        """Set up the custom binary for a particular job."""
        # Check if this build is dependent on any other custom job. If yes,
        # then fake out our job name for setting up the build.
        old_job_id = ''
        share_build_job_id = environment.get_value('SHARE_BUILD_WITH_JOB_ID')
        if share_build_job_id:
            job_id = share_build_job_id
            old_job_id = self.job_id
            environment.set_value('JOB_ID', str(job_id))
        else:
            job_id = self.job_id

        # Verify that this is really a custom binary job.
        api_client = get_api_client()
        job = api_client.job_api.get_job(job_id)
        if not job or not job.custom_binary_key or not job.custom_binary_filename:
            logs.log_error(
                'Job does not have a custom binary, even though CUSTOM_BINARY is set.')
            return False

        
        base_build_dir = get_base_build_dir(f"", job_id)

        build = CustomBuild(
            job.project_id,
            base_build_dir,
            job.custom_binary_key,
            job.custom_binary_filename,
            job.custom_binary_revision,
            target_weights=self.target_weights)

        # Revert back the actual job name.
        if share_build_job_id:
            environment.set_value('JOB_ID', str(old_job_id))

        if build.setup():
            return build

        return None

    def setup_production_build(self, build_type):
        """Sets up build with a particular revision."""
        # Bail out if there are not extended stable, stable and beta build urls.
        
        if build_type == 'extended_stable':
            build_path = environment.get_value('EXTENDED_STABLE_BUILD_BUCKET_PATH')
        elif build_type == 'stable':
            build_path = environment.get_value('STABLE_BUILD_BUCKET_PATH')
        elif build_type == 'beta':
            build_path = environment.get_value('BETA_BUILD_BUCKET_PATH')
        else:
            logs.log_error('Unknown build type %s.' % build_type)
            return None

        build_urls = get_build_packages_list(project_id=self.project.id, kind=build_type, bucket_path=build_path)
        if not build_urls:
            logs.log_error(
                'Error getting list of build urls from pingu_sdk.%s.' % build_path)
            return None

        # First index is the latest build for that version.
        build_path = build_urls[0]
        version_pattern = environment.get_value('VERSION_PATTERN')
        v_match = re.match(version_pattern, build_path)
        if not v_match:
            logs.log_error(
                'Unable to find version information from pingu_sdk.the build url %s.' % build_path)
            return None

        version = v_match.group(1)
        base_build_dir = get_base_build_dir(build_path, self.job.id)

        build_class = ProductionBuild

        build = build_class(
            base_build_dir=base_build_dir, 
            version=version,
            build_path=build_path,
            build_type=build_type,
            project_id=self.project.id)

        if build.setup():
            return build

        return None

    def setup_system_binary(self):
        """Set up a build that we assume is already installed on the system."""
        system_binary_directory = environment.get_value('SYSTEM_BINARY_DIR', '')
        build = SystemBuild(system_binary_directory)
        if build.setup():
            return build

        return None

    def setup_build(self):
        """Set up a custom or regular build based on revision."""
        # For custom binaries we always use the latest version. Revision is ignored.
        custom_binary = environment.get_value('CUSTOM_BINARY')
        if custom_binary:
            return self.setup_custom_binary()

        # In this case, we assume the build is already installed on the system.
        system_binary = environment.get_value('SYSTEM_BINARY_DIR')
        if system_binary:
            return self.setup_system_binary()

        fuzz_target_build_bucket_path = get_bucket_path('FUZZ_TARGET_BUILD_BUCKET_PATH')

        if fuzz_target_build_bucket_path:
            self.bucket_path = fuzz_target_build_bucket_path
            # Split fuzz target build.
            return self._setup_split_targets_build(BuildType.RELEASE)

        if self.revision:
            # Setup regular build with revision.
            return self.setup_regular_build(BuildType.RELEASE)

        # If no revision is provided, we default to a trunk build.
        build_storages = []
        for env_var in DEFAULT_BUILD_BUCKET_PATH_ENV_VARS:
            bucket_path = get_bucket_path(env_var)
            if bucket_path:
                match env_var:
                    case 'RELEASE_BUILD_BUCKET_PATH':
                        build_type, bucket_path = build_buckets_storages(bucket_path)
                    case 'SYM_RELEASE_BUILD_BUCKET_PATH':
                        build_type, bucket_path = build_buckets_storages(bucket_path, data_constants.Supported_Builds.SYM_RELEASE)
                    case 'SYM_DEBUG_BUILD_BUCKET_PATH':
                        build_type, bucket_path = build_buckets_storages(bucket_path, data_constants.Supported_Builds.SYM_DEBUG)
                        
                build_storages.append((build_type, bucket_path))
        
        return self.setup_trunk_build(build_storages)
