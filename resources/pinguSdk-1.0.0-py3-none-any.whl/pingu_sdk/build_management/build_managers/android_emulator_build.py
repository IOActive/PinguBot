import os
from pingu_sdk.build_management.build_managers.regular_build import RegularBuild
from pingu_sdk.metrics import logs
from pingu_sdk.system import archive, environment, new_process, shell


class AndroidEmulatorBuild(RegularBuild):
    """Represents an Android Emulator build."""

    def setup(self):
        """Android Emulator build setup."""
        self._pre_setup()

        # Download emulator image.
        if not environment.get_value('ANDROID_EMULATOR_BUCKET_PATH'):
            logs.log_error('ANDROID_EMULATOR_BUCKET_PATH is not set.')
            return False
        archive_src_path = environment.get_value('ANDROID_EMULATOR_BUCKET_PATH')
        archive_dst_path = os.path.join(self.base_build_dir, 'emulator_bundle.zip')
        
        # TODO: add emualtor bucket to the infra myabe create a artifacts bucket?
        #storage.copy_file_from(archive_src_path, archive_dst_path)

        # Extract emulator image.
        self.emulator_path = os.path.join(self.base_build_dir, 'emulator')
        shell.remove_directory(self.emulator_path)
        archive.unpack(archive_dst_path, self.emulator_path)
        shell.remove_file(archive_dst_path)

        # Stop any stale emulator instances.
        stop_script_path = os.path.join(self.emulator_path, 'stop')
        stop_proc = new_process.ProcessRunner(stop_script_path)
        stop_proc.run_and_wait()

        return super().setup()

