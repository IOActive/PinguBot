import os
from pingu_sdk.system import shell, utils

TIMESTAMP_FILE = '.timestamp'

class BaseBuild:
    """Represents a build."""

    def __init__(self, base_build_dir):
        self.base_build_dir = base_build_dir

    def last_used_time(self):
        """Return the last used time for the build."""
        timestamp_file_path = os.path.join(self.base_build_dir, TIMESTAMP_FILE)
        timestamp = utils.read_data_from_file(timestamp_file_path, eval_data=True)

        return timestamp or 0

    def delete(self):
        """Delete this build."""
        shell.remove_directory(self.base_build_dir)

    def _setup_build_directories(self):
        """Set up build directories for a job."""
        # Create the root build directory for this job.
        shell.create_directory(self.base_build_dir, create_intermediates=True)

        custom_binary_directory = os.path.join(self.base_build_dir, 'custom')
        revision_build_directory = os.path.join(self.base_build_dir, 'revisions')
        sym_build_directory = os.path.join(self.base_build_dir, 'symbolized')
        sym_debug_build_directory = os.path.join(sym_build_directory, 'debug')
        sym_release_build_directory = os.path.join(sym_build_directory, 'release')
        build_directories = [
            custom_binary_directory, revision_build_directory, sym_build_directory,
            sym_debug_build_directory, sym_release_build_directory
        ]
        for build_directory in build_directories:
            shell.create_directory(build_directory)