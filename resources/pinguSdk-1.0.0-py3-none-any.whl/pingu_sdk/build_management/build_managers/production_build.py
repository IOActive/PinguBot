import os
from pingu_sdk.build_management import revisions
from pingu_sdk.build_management.build_managers.build import Build
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment


class ProductionBuild(Build):
    """Production build."""

    def __init__(self, base_build_dir, version, build_path, project_id, build_type):
        super().__init__(base_build_dir, version)
        self.build_path = build_path
        self.build_type = build_type
        self._build_dir = os.path.join(self.base_build_dir, self.build_type)
        self.project_id = project_id

    @property
    def build_dir(self):
        return self._build_dir

    def setup(self):
        """Sets up build with a particular revision."""
        self._pre_setup()
        logs.log('Retrieving %s branch (%s).' % (self.build_type, self.revision))
        environment.set_value('BUILD_URL', self.build_path)

        version_file = os.path.join(self.build_dir, 'VERSION')
        build_update = revisions.needs_update(version_file, self.revision)

        if build_update:
            if not self._unpack_build(self.base_build_dir, self.build_dir,
                                      self.build_path, project_id=self.project_id, build_type=self.build_type):
                return False

            revisions.write_revision_to_revision_file(version_file, self.revision)
            logs.log('Retrieved %s branch (%s).' % (self.build_type, self.revision))
        else:
            logs.log('Build already exists.')

        self._setup_application_path(build_update=build_update)

        # 'VERSION' file already written.
        self._post_setup_success(update_revision=False)
        return True

