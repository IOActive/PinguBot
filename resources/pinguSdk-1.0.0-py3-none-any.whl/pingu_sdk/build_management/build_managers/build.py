"""Build manager."""
from collections import namedtuple
import shutil
import subprocess
import time
import os

from pingu_sdk.build_management import revisions
from pingu_sdk.build_management.build_managers.base_build import TIMESTAMP_FILE, BaseBuild
from pingu_sdk.build_management.build_managers.build_utils import REVISION_FILE_NAME, UNPACK_TIME_LIMIT, \
    get_file_match_callback, \
    set_random_build_scripts_for_fuzzing_if_needed, \
    set_random_fuzz_target_for_fuzzing_if_needed, get_rpaths, handle_unrecoverable_error_on_windows, set_environment_vars, set_rpaths
from pingu_sdk.build_management.minijail_build_runner import MinijailBuildRunner
from pingu_sdk.metrics import logs
from pingu_sdk.platforms import android
from pingu_sdk.system import environment, shell, archive, minijail
from pingu_sdk.utils import utils
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

# Indicates if this is a partial build (due to selected files copied from pingu_sdk.fuzz
# target).
PARTIAL_BUILD_FILE = '.partial_build'

# Build eviction constants.
MAX_EVICTED_BUILDS = 100
MIN_FREE_DISK_SPACE_CHROMIUM = 10 * 1024 * 1024 * 1024  # 10 GB
MIN_FREE_DISK_SPACE_DEFAULT = 5 * 1024 * 1024 * 1024  # 5 GB

class Build(BaseBuild):
    """Represent a build type at a particular revision."""

    def __init__(self, base_build_dir, revision, build_prefix=''):
        super().__init__(base_build_dir)
        self.revision = revision
        self.build_prefix = build_prefix
        self.env_prefix = build_prefix + '_' if build_prefix else ''

    def _reset_cwd(self):
        """Reset current working directory. Needed to clean up build
    without hitting dir-in-use exception on Windows."""
        root_directory = environment.get_value('ROOT_DIR')
        os.chdir(root_directory)

    def _delete_partial_build_file(self):
        """Deletes partial build file (if present). This is needed to make sure we
    clean up build directory if the previous build was partial."""
        partial_build_file_path = os.path.join(self.build_dir, PARTIAL_BUILD_FILE)
        if os.path.exists(partial_build_file_path):
            self.delete()

    def _pre_setup(self):
        """Common pre-setup."""
        self._reset_cwd()
        shell.clear_temp_directory()

        self._delete_partial_build_file()

        if self.base_build_dir:
            self._setup_build_directories()

        environment.set_value(self.env_prefix + 'APP_REVISION', self.revision)
        environment.set_value(self.env_prefix + 'APP_PATH', '')
        environment.set_value(self.env_prefix + 'APP_PATH_DEBUG', '')

    def _patch_rpath(self, binary_path, instrumented_library_paths):
        """Patch rpaths of a binary to point to instrumented libraries"""
        rpaths = get_rpaths(binary_path)
        # Discard all RPATHs that aren't relative to build.
        rpaths = [rpath for rpath in rpaths if '$ORIGIN' in rpath]

        for additional_path in reversed(instrumented_library_paths):
            if additional_path not in rpaths:
                rpaths.insert(0, additional_path)

        set_rpaths(binary_path, rpaths)

    def _patch_rpaths(self, instrumented_library_paths):
        """Patch rpaths of builds to point to instrumented libraries."""
        if environment.is_engine_fuzzer_job():
            # Import here as this path is not available in App Engine context.
            from pingu_sdk.fuzzers import utils

            for target_path in utils.get_fuzz_targets(self.build_dir):
                self._patch_rpath(target_path, instrumented_library_paths)
        else:
            app_path = environment.get_value('APP_PATH')
            if app_path:
                self._patch_rpath(app_path, instrumented_library_paths)

            app_path_debug = environment.get_value('APP_PATH_DEBUG')
            if app_path_debug:
                self._patch_rpath(app_path_debug, instrumented_library_paths)

    def _post_setup_success(self, update_revision=True):
        """Common post-setup."""
        if update_revision:
            self._write_revision()

        # Update timestamp to indicate when this build was last used.
        if self.base_build_dir:
            timestamp_file_path = os.path.join(self.base_build_dir, TIMESTAMP_FILE)
            utils.write_data_to_file(time.time(), timestamp_file_path)

        # Update rpaths if necessary (for e.g. instrumented libraries).
        instrumented_library_paths = environment.get_instrumented_libraries_paths()
        if instrumented_library_paths:
            self._patch_rpaths(instrumented_library_paths)

    def _unpack_build(self,
                      base_build_dir,
                      build_dir,
                      build_path,
                      target_weights=None,
                      project_id=None,
                      build_type=None
        ):
        """Unpacks a build from storage a build into the build directory."""
        # Track time taken to unpack builds so that it doesn't silently regress.
        start_time = time.time()

        # Free up memory.
        utils.python_gc()

        # Remove the current build.
        logs.log('Removing build directory %s.' % build_dir)
        if not shell.remove_directory(build_dir, recreate=True):
            logs.log_error('Unable to clear build directory %s.' % build_dir)
            handle_unrecoverable_error_on_windows()
            return False

        # Decide whether to use cache build archives or not.
        use_cache = environment.get_value('CACHE_STORE', False)

        # Download build archive locally.
        build_local_archive = os.path.join(build_dir, os.path.basename(build_path))

        # Make the disk space necessary for the archive available.
        api_client = get_api_client()
        archive_size = api_client.storage_build_api.get_build_size(project_id, build_type, build_path)
                
        if archive_size is not None and not self._make_space(archive_size,
                                                        base_build_dir):
            shell.clear_data_directories()
            logs.log_fatal_and_exit(
                'Failed to make space for download. '
                'Cleared all data directories to free up space, exiting.')

        logs.log('Downloading build from pingu_sdk.url %s.' % build_path)
        try:
            build_package_stream = api_client.storage_build_api.download_build(project_id, build_type, build_path)
            with open(build_local_archive, 'wb') as f:
                f.write(build_package_stream)
        except:
            logs.log_error('Unable to download build url %s.' % build_path)
            return False

        unpack_everything = environment.get_value(
            'UNPACK_ALL_FUZZ_TARGETS_AND_FILES')
        if not unpack_everything:
            # For fuzzing, pick a random fuzz target so that we only un-archive that
            # particular fuzz target and its dependencies and save disk space.  If we
            # are going to unpack everythng in archive based on
            # |UNPACK_ALL_FUZZ_TARGETS_AND_FILES| in the job definition, then don't
            # set a random fuzz target before we've unpacked the build. It won't
            # actually save us anything in this case and can be really expensive for
            # large builds (such as Chrome OS). Defer setting it until after the build
            # has been unpacked.
            self._pick_fuzz_target(self._get_fuzz_targets_from_archive(build_local_archive), target_weights)

        # Actual list of files to unpack can be smaller if we are only unarchiving
        # a particular fuzz target.
        file_match_callback = get_file_match_callback()
        assert not (unpack_everything and file_match_callback is not None)

        if not self._make_space_for_build(build_local_archive, base_build_dir,
                                     file_match_callback):
            shell.clear_data_directories()
            logs.log_fatal_and_exit(
                'Failed to make space for build. '
                'Cleared all data directories to free up space, exiting.')

        # Unpack the local build archive.
        logs.log('Unpacking build archive %s.' % build_local_archive)
        trusted = True  # not utils.is_oss_fuzz()
        try:
            archive.unpack(
                build_local_archive,
                build_dir,
                trusted=trusted,
                file_match_callback=file_match_callback)
        except:
            logs.log_error('Unable to unpack build archive %s.' % build_local_archive)
            return False

        if unpack_everything:
            # Set a random fuzz target now that the build has been unpacked, if we
            # didn't set one earlier. For an auxiliary build, fuzz target is already
            # specified during main build unpacking.
            if self._pick_build_script(self._get_build_scripts_from_dir(build_dir), target_weights):
                self._build_targets(environment.get_value('BUILD_SCRIPT'))
            self._pick_fuzz_target(
                self._get_fuzz_targets_from_dir(build_dir), target_weights)

        # If this is partial build due to selected build files, then mark it as such
        # so that it is not re-used.
        if file_match_callback:
            partial_build_file_path = os.path.join(build_dir, PARTIAL_BUILD_FILE)
            utils.write_data_to_file('', partial_build_file_path)

        # No point in keeping the archive around.
        shell.remove_file(build_local_archive)

        end_time = time.time()
        elapsed_time = end_time - start_time
        log_func = logs.log_warn if elapsed_time > UNPACK_TIME_LIMIT else logs.log
        log_func('Build took %0.02f minutes to unpack.' % (elapsed_time / 60.))

        return True

    def _build_targets(self, path):
        # To ensure that we can run the build script.
        os.chmod(path, 0o755)
        base_dir, build_script = os.path.split(path)
        command = "./" + build_script
        try:
            os.chdir(base_dir)
            p = subprocess.Popen(
                command, stdout=subprocess.PIPE, shell=True)

            (output, err) = p.communicate()

            # This makes the wait possible
            p_status = p.wait()
        except Exception as e:
            logs.log_error(e)

    def _build_targets_minijail(self, path):
        try:
            base_dir, build_script = os.path.split(path)
            minijail_chroot = minijail.MinijailChroot(base_dir=base_dir)
            # To ensure that we can run the build script.
            os.chmod(path, 0o755)
            minijail_chroot.add_binding(
                minijail.ChrootBinding(base_dir, "/build", writeable=False))
            minijail_chroot.add_binding(
                minijail.ChrootBinding(base_dir, '/out', writeable=False))

            minijail_bin = os.path.join(minijail_chroot.directory, 'bin')
            shell.create_directory(minijail_bin)

            # copy /bin/sh, necessary for system().
            shutil.copy(os.path.realpath('/bin/sh'), os.path.join(minijail_bin, 'sh'))
            runner = MinijailBuildRunner(executable_path=build_script, chroot=minijail_chroot)
            runner.build()
        except Exception as e:
            logs.log_error(e)

    def _get_fuzz_targets_from_archive(self, archive_path):
        """Get iterator of fuzz targets from pingu_sdk.archive path."""
        # Import here as this path is not available in App Engine context.
        import fuzzers.utils as fuzzer_utils

        for archive_file in archive.iterator(archive_path):
            if fuzzer_utils.is_fuzz_target_local(archive_file.name,
                                                 archive_file.handle):
                fuzz_target = os.path.splitext(os.path.basename(archive_file.name))[0]
                yield fuzz_target

    def _get_fuzz_targets_from_dir(self, build_dir):
        """Get iterator of fuzz targets from pingu_sdk.build dir."""
        # Import here as this path is not available in App Engine context.
        from pingu_sdk.fuzzers import utils as fuzzer_utils

        for path in fuzzer_utils.get_fuzz_targets(build_dir):
            yield os.path.splitext(os.path.basename(path))[0]

    def _pick_fuzz_target(self, fuzz_targets, target_weights):
        """Selects a fuzz target for fuzzing."""
        return set_random_fuzz_target_for_fuzzing_if_needed(
            fuzz_targets, target_weights)

    def _get_build_scripts_from_dir(self, build_dir):
        """Get iterator of fuzz targets from pingu_sdk.build dir."""
        # Import here as this path is not available in App Engine context.
        from pingu_sdk.fuzzers import utils as fuzzer_utils

        for path in fuzzer_utils.get_build_scripts(build_dir):
            yield path

    def _pick_build_script(self, build_scripts, target_weights):
        """Selects a fuzz target for fuzzing."""
        return set_random_build_scripts_for_fuzzing_if_needed(
            build_scripts, target_weights)

    def setup(self):
        """Set up the build on disk, and set all the necessary environment
    variables. Should return whether or not build setup succeeded."""
        raise NotImplementedError

    @property
    def build_dir(self):
        """The build directory. Usually a subdirectory of base_build_dir."""
        raise NotImplementedError

    def exists(self):
        """Check if build already exists."""
        revision_file = os.path.join(self.build_dir, REVISION_FILE_NAME)
        if os.path.exists(revision_file):
            with open(revision_file, 'r') as file_handle:
                try:
                    current_revision = int(file_handle.read())
                except ValueError:
                    current_revision = -1

            # We have the revision required locally, no more work to do, other than
            # setting application path environment variables.
            if self.revision == current_revision:
                return True

        return False

    def delete(self):
        """Delete this build."""
        # This overrides BaseBuild.delete (which deletes the entire base build
        # directory) to delete this specific build.
        shell.remove_directory(self.build_dir)

    def _write_revision(self):
        revision_file = os.path.join(self.build_dir, REVISION_FILE_NAME)
        revisions.write_revision_to_revision_file(revision_file, self.revision)

    def _setup_application_path(self,
                                build_dir=None,
                                app_path='APP_PATH',
                                build_update=False):
        """Sets up APP_PATH environment variables for revision build."""
        logs.log('Setup application path.')

        if not build_dir:
            build_dir = self.build_dir

        # Make sure to initialize so that we don't carry stale values
        # in case of errors. app_path can be APP_PATH or APP_PATH_DEBUG.
        app_path = self.env_prefix + app_path
        environment.set_value(app_path, '')
        environment.set_value(self.env_prefix + 'APP_DIR', '')
        environment.set_value(self.env_prefix + 'BUILD_DIR', build_dir)
        environment.set_value(self.env_prefix + 'GN_ARGS_PATH', '')
        environment.set_value(self.env_prefix + 'LLVM_SYMBOLIZER_PATH',
                              environment.get_default_tool_path('llvm-symbolizer'))

        # Initialize variables.
        fuzzer_directory = environment.get_value('FUZZER_DIR')
        search_directories = [build_dir]
        if fuzzer_directory:
            search_directories.append(fuzzer_directory)

        set_environment_vars(
            search_directories, app_path=app_path, env_prefix=self.env_prefix)

        absolute_file_path = environment.get_value(app_path)
        app_directory = environment.get_value(self.env_prefix + 'APP_DIR')

        if not absolute_file_path:
            return

        # Set the symlink if needed.
        symbolic_link_target = environment.get_value(self.env_prefix +
                                                     'SYMBOLIC_LINK')
        if symbolic_link_target:
            os.system('mkdir --parents %s' % os.path.dirname(symbolic_link_target))
            os.system('rm %s' % symbolic_link_target)
            os.system('ln -s %s %s' % (app_directory, symbolic_link_target))

        if not environment.is_android():
            return

        android.device.update_build(absolute_file_path, force_update=build_update)

    def _make_space(self, requested_size, current_build_dir=None):
        """Try to make the requested number of bytes available by deleting builds."""

        min_free_disk_space = MIN_FREE_DISK_SPACE_DEFAULT

        builds_directory = environment.get_value('BUILDS_DIR')

        error_message = 'Need at least %d GB of free disk space.' % ((
                (min_free_disk_space + requested_size) // 1024 ** 3))
        for _ in range(MAX_EVICTED_BUILDS):
            free_disk_space = shell.get_free_disk_space(builds_directory)
            if free_disk_space is None:
                # Can't determine free disk space, bail out.
                return False

            if requested_size + min_free_disk_space < free_disk_space:
                return True

            if not self._evict_build(current_build_dir):
                logs.log_error(error_message)
                return False

        free_disk_space = shell.get_free_disk_space(builds_directory)
        result = requested_size + min_free_disk_space < free_disk_space
        if not result:
            logs.log_error(error_message)
        return result


    def _make_space_for_build(self, build_local_archive,
                            current_build_dir,
                            file_match_callback=None):
        """Make space for extracting the build archive by deleting the least recently
    used builds."""
        extracted_size = archive.extracted_size(
            build_local_archive, file_match_callback=file_match_callback)

        return self._make_space(extracted_size, current_build_dir=current_build_dir)


    def _evict_build(self, current_build_dir):
        """Remove the least recently used build to make room."""
        builds_directory = environment.get_value('BUILDS_DIR')
        least_recently_used = None
        least_recently_used_timestamp = None

        for build_directory in os.listdir(builds_directory):
            absolute_build_directory = os.path.join(builds_directory, build_directory)
            if not os.path.isdir(absolute_build_directory):
                continue

            if absolute_build_directory == current_build_dir:
                # Don't evict the build we're trying to extract.
                continue

            build = BaseBuild(absolute_build_directory)
            timestamp = build.last_used_time()

            if (least_recently_used_timestamp is None or
                    timestamp < least_recently_used_timestamp):
                least_recently_used_timestamp = timestamp
                least_recently_used = build

        if not least_recently_used:
            return False

        logs.log(
            'Deleting build %s to save space.' % least_recently_used.base_build_dir)
        least_recently_used.delete()

        return True
