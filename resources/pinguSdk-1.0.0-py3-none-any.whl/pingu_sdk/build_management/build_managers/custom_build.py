import os
from pingu_sdk.build_management import revisions
from pingu_sdk.build_management.build_managers.build import Build
from pingu_sdk.build_management.build_managers.build_utils import REVISION_FILE_NAME, handle_unrecoverable_error_on_windows, handle_unrecoverable_error_on_windows
from pingu_sdk.metrics import logs
from pingu_sdk.system import archive, environment, shell
from pingu_sdk.datastore import blobs_manager


class CustomBuild(Build):
    """Custom binary."""

    def __init__(self,
                 project_id,
                 base_build_dir,
                 custom_binary_key,
                 custom_binary_filename,
                 custom_binary_revision,
                 target_weights=None):
        super().__init__(base_build_dir, custom_binary_revision)
        self.custom_binary_key = custom_binary_key
        self.custom_binary_filename = custom_binary_filename
        self._build_dir = os.path.join(self.base_build_dir, 'custom')
        self.target_weights = target_weights
        self.project_id = project_id

    @property
    def build_dir(self):
        return self._build_dir

    def _unpack_custom_build(self):
        """Unpack the custom build."""
        if not shell.remove_directory(self.build_dir, recreate=True):
            logs.log_error('Unable to clear custom binary directory.')
            handle_unrecoverable_error_on_windows()
            return False

        build_local_archive = os.path.join(self.build_dir,
                                           self.custom_binary_filename)
        if not blobs_manager.read_blob_to_disk(self.project_id, self.custom_binary_key, build_local_archive):
             return False

        # If custom binary is an archive, then unpack it.
        if archive.is_archive(self.custom_binary_filename):
            if not self._make_space_for_build(build_local_archive, self.base_build_dir):
                # Remove downloaded archive to free up space and otherwise, it won't get
                # deleted until next job run.
                shell.remove_file(build_local_archive)

                logs.log_fatal_and_exit('Could not make space for build.')

            try:
                archive.unpack(build_local_archive, self.build_dir, trusted=True)
            except:
                logs.log_error(
                    'Unable to unpack build archive %s.' % build_local_archive)
                return False

            # Remove the archive.
            shell.remove_file(build_local_archive)

        self._pick_fuzz_target(
            self._get_fuzz_targets_from_dir(self.build_dir), self.target_weights)
        return True

    def setup(self):
        """Set up the custom binary for a particular job."""
        self._pre_setup()

        # Track the key for the custom binary so we can create a download link
        # later.
        environment.set_value('BUILD_KEY', self.custom_binary_key)

        logs.log('Retrieving custom binary build r%d.' % self.revision)

        revision_file = os.path.join(self.build_dir, REVISION_FILE_NAME)
        build_update = revisions.needs_update(revision_file, self.revision)

        if build_update:
            if not self._unpack_custom_build():
                return False

            logs.log('Retrieved custom binary build r%d.' % self.revision)
        else:
            logs.log('Build already exists.')

            self._pick_fuzz_target(
                self._get_fuzz_targets_from_dir(self.build_dir), self.target_weights)

        self._setup_application_path(build_update=build_update)
        self._post_setup_success(update_revision=build_update)
        return True

