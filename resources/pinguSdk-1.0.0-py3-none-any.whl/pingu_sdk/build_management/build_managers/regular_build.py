import os
from pingu_sdk.build_management.build_managers.build import Build
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment


class RegularBuild(Build):
    """Represents a regular build."""

    def __init__(self,
                 base_build_dir,
                 revision,
                 project_id,
                 build_type,
                 build_path,
                 target_weights=None,
                 build_prefix=''):
        
        super().__init__(
            base_build_dir=base_build_dir, 
            revision=revision,  
            build_prefix=build_prefix)
        
        if build_prefix:
            self.build_dir_name = build_prefix.lower()
        else:
            self.build_dir_name = 'revisions'

        self._build_dir = os.path.join(self.base_build_dir, self.build_dir_name)
        self.target_weights = target_weights
        
        self.project_id=project_id
        self.build_type=build_type
        self.build_path = build_path

    @property
    def build_dir(self):
        return self._build_dir

    def setup(self):
        """Sets up build with a particular revision."""
        self._pre_setup()
        environment.set_value(self.env_prefix + 'BUILD_URL', self.build_path)

        logs.log('Retrieving build r%d.' % self.revision)
        build_update = not self.exists()
        if build_update:
            if not self._unpack_build(self.base_build_dir, self.build_dir,
                                      self.build_path, self.target_weights, self.project_id, self.build_type):
                return False

            logs.log('Retrieved build r%d.' % self.revision)
        else:
            self._pick_fuzz_target(
                self._get_fuzz_targets_from_dir(self.build_dir), self.target_weights)

            # We have the revision required locally, no more work to do, other than
            # setting application path environment variables.
            logs.log('Build already exists.')

        self._setup_application_path(build_update=build_update)
        self._post_setup_success(update_revision=build_update)

        return True

