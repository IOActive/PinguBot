import os
from pingu_sdk.build_management.build_managers.regular_build import RegularBuild
from pingu_sdk.metrics import logs
from pingu_sdk.system import archive, environment, shell


class CuttlefishKernelBuild(RegularBuild):
    """Represents a Android Cuttlefish kernel build."""

    _IMAGE_FILES = ('bzImage', 'initramfs.img')

    def setup(self):
        """Android kernel build setup."""
        from pingu_sdk.platforms.android import adb

        result = super().setup()
        if not result:
            return result

        # Download syzkaller binary folder.
        if not environment.get_value('SYZKALLER_BUCKET_PATH'):
            logs.log_error('SYZKALLER_BUCKET_PATH is not set for syzkaller.')
            return False
        archive_src_path = environment.get_value('SYZKALLER_BUCKET_PATH')
        archive_dst_path = os.path.join(self.build_dir, 'syzkaller.zip')
        
        # TODO create this maybe in the future 
        # storage.copy_file_from(archive_src_path, archive_dst_path)

        # Extract syzkaller binary.
        syzkaller_path = os.path.join(self.build_dir, 'syzkaller')
        shell.remove_directory(syzkaller_path)
        archive.unpack(archive_dst_path, syzkaller_path)
        shell.remove_file(archive_dst_path)

        environment.set_value('VMLINUX_PATH', self.build_dir)

        cvd_dir = environment.get_value('CVD_DIR')
        adb.stop_cuttlefish_device()

        for image_filename in self._IMAGE_FILES:
            # Copy new kernel image to Cuttlefish.
            image_src = os.path.join(self.build_dir, image_filename)
            image_dest = os.path.join(cvd_dir, image_filename)
            adb.copy_to_cuttlefish(image_src, image_dest)

        adb.start_cuttlefish_device(use_kernel=True)
        adb.connect_to_cuttlefish_device()

        return True

