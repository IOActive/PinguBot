import os
from pingu_sdk.build_management.build_managers.build import Build
from pingu_sdk.build_management.build_managers.build_utils import handle_unrecoverable_error_on_windows, handle_unrecoverable_error_on_windows
from pingu_sdk.datastore.pingu_api.storage.build_api import BuildType
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment, shell


class SymbolizedBuild(Build):
    """Symbolized build."""

    def __init__(self, base_build_dir, revision, release_build_path,
                 debug_build_path,  project_id):
        super().__init__(base_build_dir, revision)
        
        self._build_dir = os.path.join(self.base_build_dir, 'symbolized')
        self.release_build_dir = os.path.join(self.build_dir, 'release')
        self.debug_build_dir = os.path.join(self.build_dir, 'debug')

        self.release_build_path = release_build_path
        self.debug_build_path = debug_build_path
        
        self.project_id=project_id

    @property
    def build_dir(self):
        return self._build_dir

    def _unpack_builds(self):
        """Download and unpack builds."""
        if not shell.remove_directory(self.build_dir, recreate=True):
            logs.log_error('Unable to clear symbolized build directory.')
            handle_unrecoverable_error_on_windows()
            return False

        if not self.release_build_path and not self.debug_build_path:
            return False

        if self.release_build_path:
            if not self._unpack_build(self.base_build_dir, self.release_build_dir,
                                      self.release_build_path, project_id=self.project_id,
                                      build_type=BuildType.SYM_RELEASE):
                return False

        if self.debug_build_path:
            if not self._unpack_build(self.base_build_dir, self.debug_build_dir,
                                      self.debug_build_path, project_id=self.project_id,
                                      build_type=BuildType.SYM_DEBUG):
                return False

        return True

    def setup(self):
        self._pre_setup()
        logs.log('Retrieving symbolized build r%d.' % self.revision)

        build_update = not self.exists()
        if build_update:
            if not self._unpack_builds():
                return False

            logs.log('Retrieved symbolized build r%d.' % self.revision)
        else:
            logs.log('Build already exists.')

        if self.release_build_path:
            self._setup_application_path(
                self.release_build_dir, build_update=build_update)
            environment.set_value('BUILD_URL', self.release_build_path)

        if self.debug_build_path:
            # Note: this will override LLVM_SYMBOLIZER_PATH, APP_DIR etc from pingu_sdk.the
            # previous release setup, which may not be desirable behaviour.
            self._setup_application_path(
                self.debug_build_dir, 'APP_PATH_DEBUG', build_update=build_update)

        self._post_setup_success(update_revision=build_update)
        return True

