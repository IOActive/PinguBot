from pingu_sdk.build_management.build_managers.build import Build
from pingu_sdk.build_management.build_managers.build_utils import BuildManagerException


class SystemBuild(Build):
    """System binary."""

    def __init__(self, system_binary_directory):
        super().__init__(None, 1)
        self._build_dir = system_binary_directory

    @property
    def build_dir(self):
        return self._build_dir

    def setup(self):
        """Set up a build that we assume is already installed on the system."""
        self._pre_setup()
        self._setup_application_path()
        return True

    def delete(self):
        raise BuildManagerException('Cannot delete system build.')

