from ast import Tuple
from collections import namedtuple
import time
from typing import List, Optional
from urllib.parse import urlparse
from uuid import UUID
from distutils import spawn
import os
import re
import subprocess

from pingu_sdk.build_management import overrides, revisions
from pingu_sdk.config.project_config import ProjectConfig
from pingu_sdk.datastore import data_constants
from pingu_sdk.datastore.models.testcase import Testcase
from pingu_sdk.datastore.pingu_api.storage.build_api import BuildType
from pingu_sdk.fuzzing import fuzzer_selection
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment, errors, shell
from pingu_sdk.utils import utils
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

# File name for storing current build revision.
REVISION_FILE_NAME = 'REVISION'

# Various build type mapping strings.
BUILD_TYPE_SUBSTRINGS = [
    '-beta', '-stable', '-debug', '-release', '-symbolized', '-extended_stable'
]

# ICU data file.
ICU_DATA_FILENAME = 'icudtl.dat'

# Extensions to exclude when unarchiving a fuzz target. Note that fuzz target
# own files like seed corpus, options, etc are covered by its own regex.
FUZZ_TARGET_EXCLUDED_EXTENSIONS = [
    'exe', 'options', 'txt', 'zip', 'exe.pdb', 'par'
]

# File prefixes to explicitly include when unarchiving a fuzz target.
FUZZ_TARGET_ALLOWLISTED_PREFIXES = [
    'afl-cmin',
    'afl-fuzz',
    'afl-showmap',
    'afl-tmin',
    'honggfuzz',
    'jazzer_agent_deploy.jar',
    'jazzer_driver',
    'jazzer_driver_with_sanitizer',
    'llvm-symbolizer',
]

# Time for unpacking a build beyond which an error should be logged.
UNPACK_TIME_LIMIT = 60 * 20

PATCHELF_SIZE_LIMIT = 1.5 * 1024 * 1024 * 1024  # 1.5 GiB

TARGETS_LIST_FILENAME = 'targets.list'

BuildPackages = namedtuple('BuildPackages', ['build_storage', 'builds_list'])


class BuildManagerException(Exception):
    """Build manager exceptions."""


def get_base_build_dir(bucket_path, job_id):
    """Get the base directory for a build."""
    return _get_build_directory(bucket_path, str(job_id))


def handle_unrecoverable_error_on_windows():
    """Handle non-recoverable error on Windows. This is usually either due to disk
  corruption or processes failing to terminate using regular methods. Force a
  restart for recovery."""
    if environment.platform() != 'WINDOWS':
        return

    logs.log_error('Unrecoverable error, restarting machine...')
    time.sleep(60)
    utils.restart_machine()


def get_file_match_callback():
    """Returns a file match callback to decide which files to unpack in an
  archive.
  """
    # Don't return a callback to decide what to selectively unpack if
    # UNPACK_ALL_FUZZ_TARGETS_AND_FILES is set. Otherwise we are not actually
    # going to unpack all.
    if environment.get_value('UNPACK_ALL_FUZZ_TARGETS_AND_FILES'):
        return None

    fuzz_target = environment.get_value('FUZZ_TARGET')
    if not fuzz_target:
        # File match regex is only applicable for libFuzzer and afl fuzz targets.
        return None

    logs.log('Extracting only files for target %s.' % fuzz_target)

    allowlisted_names = tuple([fuzz_target] + FUZZ_TARGET_ALLOWLISTED_PREFIXES)
    blocklisted_extensions = tuple(
        '.' + extension for extension in FUZZ_TARGET_EXCLUDED_EXTENSIONS)

    def file_match_callback(filepath):
        """Returns True if any part (ie: directory or file) of the |filepath| starts
     with one of the |allowlisted_names| or has an extension but does not end
     with one of the |blocklisted_extensions|.
    """
        path_components = os.path.normpath(filepath).split(os.sep)
        # Is it an allowlisted binary?
        if any(
                component.startswith(allowlisted_names)
                for component in path_components):
            return True

        basename = os.path.basename(filepath)
        # Does it have a blocklisted extension?
        if basename.endswith(blocklisted_extensions):
            return False

        # Does it have an extension?
        if '.' in basename:
            return True

        return False

    return file_match_callback

def _get_build_directory(bucket_path, job_id):
    """Return the build directory based on bucket path and job name."""
    builds_directory = environment.get_value('BUILDS_DIR')

    # In case we have a bucket path, we want those to share the same build
    # directory.
    if bucket_path:
        if '/' not in bucket_path:
            file_pattern = bucket_path
        else:
            bucket_path, file_pattern = bucket_path.rsplit('/', 1)
            bucket_path = bucket_path.replace('/', '_')
            bucket_path = bucket_path.split("_")[-1]

        # Remove similar build types to force them in same directory.
        file_pattern = utils.remove_sub_strings(file_pattern, BUILD_TYPE_SUBSTRINGS)

        file_pattern_hash = utils.string_hash(file_pattern)
        job_directory = '%s_%s' % (bucket_path, file_pattern_hash)
        #job_directory = '%s' % (bucket_path)

    else:
        job_directory = job_id

    return os.path.join(builds_directory, job_directory)


def set_random_fuzz_target_for_fuzzing_if_needed(fuzz_targets, target_weights):
    """Sets a random fuzz target for fuzzing."""
    fuzz_target = environment.get_value('FUZZ_TARGET')
    if fuzz_target:
        logs.log('Use previously picked fuzz target %s for fuzzing.' % fuzz_target)
        return fuzz_target

    fuzz_targets = list(fuzz_targets)
    if not fuzz_targets:
        logs.log_error('No fuzz targets found. Unable to pick random one.')
        return None

    environment.set_value('FUZZ_TARGET_COUNT', len(fuzz_targets))

    fuzz_target = fuzzer_selection.select_fuzz_target(fuzz_targets,
                                                      target_weights)
    environment.set_value('FUZZ_TARGET', fuzz_target)
    logs.log('Picked fuzz target %s for fuzzing.' % fuzz_target)

    return fuzz_target


def set_random_build_scripts_for_fuzzing_if_needed(build_scripts, target_weights):
    """Sets a random fuzz target for fuzzing."""
    build_script = environment.get_value('BUILD_SCRIPT')
    if build_script:
        logs.log('Use previously picked fuzz target %s for fuzzing.' % build_script)
        return build_script

    if not environment.is_engine_fuzzer_job():
        return None

    build_scripts = list(build_scripts)
    if not build_scripts:
        logs.log_error('No Build Scripts found. Unable to pick random one.')
        return None

    environment.set_value('BUILD_SCRIPT_COUNT', len(build_scripts))

    build_script = fuzzer_selection.select_build_script(build_scripts,
                                                        target_weights)
    environment.set_value('BUILD_SCRIPT', build_script)
    logs.log('Picked build script %s for building.' % build_script)

    return build_script


def set_environment_vars(search_directories, app_path='APP_PATH',
                         env_prefix=''):
    """Set build-related environment variables (APP_PATH, APP_DIR etc) by walking
  through the build directory."""
    app_name = environment.get_value(env_prefix + 'APP_NAME')
    llvm_symbolizer_filename = environment.get_executable_filename(
        'llvm-symbolizer')
    llvm_symbolizer_path = None
    gn_args_filename = 'args.gn'
    gn_args_path = None
    platform = environment.platform()
    absolute_file_path = None
    app_directory = None

    # Chromium specific folder to ignore.
    initialexe_folder_path = '%sinitialexe' % os.path.sep

    for search_directory in search_directories:
        for root, _, files in shell.walk(search_directory):
            # .dSYM folder contain symbol files on Mac and should
            # not be searched for application binary.
            if platform == 'MAC' and '.dSYM' in root:
                continue

            # Ignore some folders on Windows.
            if (platform == 'WINDOWS' and (initialexe_folder_path in root)):
                continue

            for filename in files:
                if not absolute_file_path and filename == app_name:
                    absolute_file_path = os.path.join(root, filename)
                    app_directory = os.path.dirname(absolute_file_path)

                    # We don't want to change the state of system binaries.
                    if not environment.get_value('SYSTEM_BINARY_DIR'):
                        os.chmod(absolute_file_path, 0o750)

                    environment.set_value(env_prefix + app_path, absolute_file_path)
                    environment.set_value(env_prefix + 'APP_DIR', app_directory)

                if not gn_args_path and filename == gn_args_filename:
                    gn_args_path = os.path.join(root, gn_args_filename)
                    environment.set_value(env_prefix + 'GN_ARGS_PATH', gn_args_path)

                if (not llvm_symbolizer_path and
                        filename == llvm_symbolizer_filename and
                        not environment.get_value('USE_DEFAULT_LLVM_SYMBOLIZER')):
                    llvm_symbolizer_path = os.path.join(root, llvm_symbolizer_filename)
                    environment.set_value(env_prefix + 'LLVM_SYMBOLIZER_PATH',
                                          llvm_symbolizer_path)


def _sort_build_packages_by_revision(build_storages, bucket_path, reverse):
    """Return a sorted list of build url by revision."""

    base_storage_path = os.path.dirname(bucket_path)
    file_pattern = os.path.basename(bucket_path)
    filename_by_revision_dict = {}

    base_path_with_seperator = base_storage_path + '/' if base_storage_path else ''

    for build_storage in build_storages:
        match_pattern = '({base_path_with_seperator})({file_pattern})'.format(
            base_path_with_seperator=base_path_with_seperator,
            file_pattern=file_pattern)
        match = re.match(match_pattern, build_storage)
        if match:
            filename = match.group(2)
            revision = match.group(3)

            # Ensure that there are no duplicate revisions.
            if revision in filename_by_revision_dict:
                job_id = environment.get_value('JOB_ID')
                raise errors.BadStateError(
                    'Found duplicate revision %s when processing bucket. '
                    'Bucket path is probably malformed for job %s.' % (revision,
                                                                       job_id))

            filename_by_revision_dict[revision] = filename

    try:
        sorted_revisions = sorted(
            filename_by_revision_dict,
            reverse=reverse,
            key=lambda x: list(map(int, x.split('.'))))
    except:
        logs.log_warn(
            'Revision pattern is not an integer, falling back to string sort.')
        sorted_revisions = sorted(filename_by_revision_dict, reverse=reverse)

    sorted_build_urls = []
    for revision in sorted_revisions:
        filename = filename_by_revision_dict[revision]
        sorted_build_urls.append('%s/%s' % (base_storage_path, filename))

    return sorted_build_urls



def get_build_packages_list(project_id: UUID, kind: BuildType, bucket_path, reverse=True):
    """Returns a sorted list of build urls from pingu_sdk.a bucket path."""
    if not project_id or not kind or not bucket_path:
        return []
        
    keys_directory = environment.get_value('BUILD_URLS_DIR')
    keys_filename = '%s.list' % utils.string_hash(f"{project_id}_{kind.value}/{bucket_path}")
    keys_file_path = os.path.join(keys_directory, keys_filename)

    # For one task, keys file that is cached locally should be re-used.
    # Otherwise, we do waste lot of network bandwidth calling and getting the
    # same set of urls (esp for regression and progression testing).
    if not os.path.exists(keys_directory):
        os.makedirs(keys_directory)

    if not os.path.exists(keys_file_path):
        # Get url list by reading the Minio bucket.
        target_list = get_api_client().storage_build_api.get_build_list(project_id, kind)
        with open(keys_file_path, 'w') as f:
            for path in target_list:
                f.write(path + '\n')

    content = utils.read_data_from_file(keys_file_path, eval_data=False).decode('utf-8')
    if not content:
        return []

    build_packages = content.splitlines()

    return _sort_build_packages_by_revision(build_packages, bucket_path, reverse)



def get_revisions_list(project_id: UUID, build_type, bucket_path=None, testcase: Testcase=None):
    """Returns a sorted ascending list of revisions from pingu_sdk.a bucket path, excluding
  bad build revisions and testcase crash revision (if any)."""
    if not bucket_path:
            bucket_path = f"{environment.get_value('RELEASE_BUILD_BUCKET_PATH')}"
            
    revision_pattern = revisions.revision_pattern_from_build_bucket_path(bucket_path)
    revision_urls = get_build_packages_list(project_id=project_id, kind=build_type, bucket_path=bucket_path, reverse=False)
    if not revision_urls:
        return None

    # Parse the revisions out of the build urls.
    revision_list = []
    for url in revision_urls:
        match = re.match(revision_pattern, url)
        if match:
            revision = revisions.convert_revision_to_integer(match.group(1))
            revision_list.append(revision)
    return revision_list


def base_fuzz_target_name(target_name):
    """Get the base fuzz target name "X" from pingu_sdk."X@Y"."""
    return target_name.split('@')[0]


def get_targets_list(project_id: UUID, kind: BuildType):
    """Get the target list for a given fuzz target bucket path. This is done by
    reading the targets.list file, which contains a list of the currently active
    fuzz targets."""
    return get_api_client().storage_build_api.get_build_list(project_id=project_id, build_type=kind)

def full_fuzz_target_path(bucket_path, fuzz_target):
    """Get the full fuzz target bucket path."""
    return bucket_path.replace('%TARGET%', base_fuzz_target_name(fuzz_target))


def get_latest_revision(build_storages: List[Tuple(BuildType, str)], project_id) -> Optional[int]:
    """Get the latest revision."""
    build_packages = []
    for build_type, build_storage in build_storages:
        builds_list = get_build_packages_list(project_id=project_id,
                                              kind=build_type,
                                              bucket_path=build_storage)
        if not builds_list:
            logs.log_error('Error getting list of build urls from storage.%s.' % build_storage)
            return None

        build_packages.append(BuildPackages(build_storage=build_storage, builds_list=builds_list))

    main_build_packages = build_packages[0]
    other_build_packages = build_packages[1:]

    revision_pattern = revisions.revision_pattern_from_build_bucket_path(main_build_packages.build_storage)
    
    for build_package in main_build_packages.builds_list:
        match = re.match(revision_pattern, build_package)
        if not match:
            continue

        revision = revisions.convert_revision_to_integer(match.group(1))
        if (not other_build_packages or all(
                revisions.find_build_packge(packge.build_storage, packge.builds_list, revision)
                for packge in other_build_packages)):
            return revision

    return None

def build_buckets_storages(bucket_path, built_type=data_constants.Supported_Builds.RELEASE):
    # Switch case for each built_type:    
    match built_type:
        case data_constants.Supported_Builds.RELEASE:
            return BuildType.RELEASE ,bucket_path
        case data_constants.Supported_Builds.SYM_RELEASE:
            return BuildType.SYM_RELEASE ,bucket_path
        case data_constants.Supported_Builds.SYM_DEBUG:
            return BuildType.SYM_DEBUG ,bucket_path
        case data_constants.Supported_Builds.STABLE:
            return BuildType.STABLE ,bucket_path
        case data_constants.Supported_Builds.BETA:
            return BuildType.BETA ,bucket_path    

def is_custom_binary():
    """Determine if this is a custom or preinstalled system binary."""
    return (environment.get_value('CUSTOM_BINARY') or
            environment.get_value('SYSTEM_BINARY_DIR'))


def has_production_builds():
    """Return a bool on if job type has build urls for extended stable, stable and
  beta builds."""
    return (environment.get_value('STABLE_BUILD_BUCKET_PATH') and
            environment.get_value('BETA_BUILD_BUCKET_PATH') and
            environment.get_value('EXTENDED_STABLE_BUILD_BUCKET_PATH'))


def has_symbolized_builds():
    """Return a bool on if job type has either a release or debug build for stack
  symbolization."""
    return (environment.get_value('SYM_RELEASE_BUILD_BUCKET_PATH') or
            environment.get_value('SYM_DEBUG_BUILD_BUCKET_PATH'))


def _set_rpaths_chrpath(binary_path, rpaths):
    """Set rpaths using chrpath."""
    chrpath = environment.get_default_tool_path('chrpath')
    if not chrpath:
        raise BuildManagerException('Failed to find chrpath')

    subprocess.check_output(
        [chrpath, '-r', ':'.join(rpaths), binary_path], stderr=subprocess.PIPE)


def _set_rpaths_patchelf(binary_path, rpaths):
    """Set rpaths using patchelf."""
    patchelf = spawn.find_executable('patchelf')
    if not patchelf:
        raise BuildManagerException('Failed to find patchelf')

    subprocess.check_output(
        [patchelf, '--force-rpath', '--set-rpath', ':'.join(rpaths), binary_path],
        stderr=subprocess.PIPE)


def set_rpaths(binary_path, rpaths):
    """Set rpath of a binary."""
    # Patchelf handles rpath patching much better, and allows e.g. extending the
    # length of the rpath. However, it loads the entire binary into memory so
    # does not work for large binaries, so use chrpath for larger binaries.
    binary_size = os.path.getsize(binary_path)
    if binary_size >= PATCHELF_SIZE_LIMIT:
        _set_rpaths_chrpath(binary_path, rpaths)
    else:
        _set_rpaths_patchelf(binary_path, rpaths)


def get_rpaths(binary_path):
    """Get rpath of a binary."""
    chrpath = environment.get_default_tool_path('chrpath')
    if not chrpath:
        raise BuildManagerException('Failed to find chrpath')

    try:
        rpaths = subprocess.check_output(
            [chrpath, '-l', binary_path],
            stderr=subprocess.PIPE).strip().decode('utf-8')
    except subprocess.CalledProcessError as e:
        if b'no rpath or runpath tag found' in e.output:
            return []

        raise

    if rpaths:
        search_marker = 'RPATH='
        start_index = rpaths.index(search_marker) + len(search_marker)
        return rpaths[start_index:].split(':')

    return []


def check_app_path(app_path='APP_PATH'):
    """Check if APP_PATH is properly set."""
    # If APP_NAME is not set (e.g. for grey box jobs), then we don't need
    # APP_PATH.
    return (not environment.get_value('APP_NAME') or
            environment.get_value(app_path))


def get_bucket_path(name):
    """Return build bucket path, applying any set overrides."""
    bucket_path = environment.get_value(name)
    bucket_path = overrides.check_and_apply_overrides(
        bucket_path, overrides.PLATFORM_ID_TO_BUILD_PATH_KEY)
    return bucket_path
