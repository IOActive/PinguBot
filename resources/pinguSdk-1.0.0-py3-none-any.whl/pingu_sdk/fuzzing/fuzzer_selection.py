
"""Helper functions to update fuzzer-job mappings, and select fuzzers to run."""

import collections
from uuid import UUID

# Used to prepare targets to be passed to utils.random_weighted_choice.
from pingu_sdk.datastore import fuzz_target_utils
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment
from pingu_sdk.utils import utils

WeightedTarget = collections.namedtuple('WeightedTarget', ['target', 'weight'])

def select_fuzz_target(targets, target_weights):
    """Select a fuzz target from pingu_sdk.a list of potential targets."""
    assert targets

    weighted_targets = []
    for target in targets:
        if target_weights:
            weight = target_weights.get(target, 1.0)
        else:
            weight = 1.0
        weighted_targets.append(WeightedTarget(target, weight))

    return utils.random_weighted_choice(weighted_targets).target


def select_build_script(build_scripts, target_weights):
    """Select a fuzz target from pingu_sdk.a list of potential targets."""
    assert build_scripts

    weighted_targets = []
    for target in build_scripts:
        weight = target_weights.get(target, 1.0)
        weighted_targets.append(WeightedTarget(target, weight))

    return utils.random_weighted_choice(weighted_targets).target


def get_fuzz_target_weights(job_id: UUID):
    """Get a list of fuzz target weights based on the current fuzzer."""
    target_jobs = fuzz_target_utils.get_fuzz_target_jobs(job_id=job_id)
    fuzz_targets = fuzz_target_utils.get_fuzz_targets_for_target_jobs(target_jobs)

    weights = {}
    for fuzz_target, target_job in zip(fuzz_targets, target_jobs):
        if not fuzz_target:
            logs.log_error('Skipping weight assignment for fuzz target %s.' %
                           target_job.fuzz_target_id)
            continue

        weights[str(fuzz_target.id)] = target_job.weight

    return weights
