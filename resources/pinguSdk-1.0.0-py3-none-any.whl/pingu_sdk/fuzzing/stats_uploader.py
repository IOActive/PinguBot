from pingu_sdk.system.utils import legalize_filenames, legalize_files
from uuid import UUID
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client


class StatsUploader(object):
    """Uploader for Stats."""

    def __init__(self,
                 project_id: UUID,
                 fuzz_target_id: UUID,
                 job_id: UUID,
                 ):
        """Inits the StatsUploader.

    Args:
      host: API host.
      auth_token: Authentication token.
      project_id: Project ID.
      fuzz_target_id: Fuzz target ID.
      job_id: Job ID.
    """
        self.project_id = project_id
        self.fuzz_target_id = fuzz_target_id
        self.job_id = job_id

    def upload_stats(self, kind: str, files: list):
        """Upload stats files to the API.

    Args:
      kind: Type of stats.
      files: List of files to upload.

    Returns:
      A bool indicating whether or not the upload succeeded.
    """
        if not files:
            return False
      
        try:
            get_api_client().storage_stats_api.upload_stats(self.project_id, self.fuzz_target_id, self.job_id, kind, files)
            return True
        except Exception as e:
            print(f"Failed to upload stats: {e}")
            return False