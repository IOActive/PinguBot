"""Uploads test cases from pingu_sdk.blackbox fuzzers for coverage collection."""

import os
from uuid import UUID
from pingu_sdk.metrics import logs

from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

COVERAGE_EXTENSIONS = [
    '.cov',
    '.profraw',
    '.profdata',
    '.lcov',
    '.gcda',
    '.gcno',
    '.gcov',
    '.clover',
    '.jacoco',
    '.coverage',
    '.coverprofile',
    '.json'
]

def _get_coverage_files(directory):
    """Get all coverage files in the given directory."""
    return [os.path.abspath(os.path.join(directory, f)) for f in os.listdir(directory) if any(f.endswith(ext) for ext in COVERAGE_EXTENSIONS)]
    
    
def upload_coverage(project_id: UUID, fuzz_target_id: UUID, binary_path, artifacts_directory, fuzzer_name):
    """Upload coverage files to a remote storage."""    
    coverage_files = _get_coverage_files(artifacts_directory)
    
    if not coverage_files:
        logs.log("No coverage files found in the artifacts directory.")
        return
    
    logs.log(f"Found {len(coverage_files)} coverage files to upload.")
    
    # Upload binary file and coverage files to the remote storage
    files = [
        {
            "name": os.path.basename(binary_path),
            "content": open(binary_path, 'rb').read(),
            "content_type": "application/octet-stream"
        }
    ]
    
    for coverage_file in coverage_files:
        files.append({
            "name": os.path.basename(coverage_file),
            "content": open(coverage_file, 'rb').read(),
            "content_type": "application/octet-stream"
        })
    
    client = get_api_client().storage_coverage_api
    client.upload_coverage(project_id, fuzz_target_id, files)