"""Functions for corpus synchronization with Storage."""

import os
import re
import shutil
from uuid import UUID

from pingu_sdk.config.project_config import ProjectConfig
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client
from pingu_sdk.datastore.pingu_api.storage.corpus_api import CorpusTypes
from pingu_sdk.metrics import logs
from pingu_sdk.system import shell
from pingu_sdk.system.utils import legalize_filenames, legalize_files

BACKUP_ARCHIVE_FORMAT = 'zip'
CORPUS_FILES_SYNC_TIMEOUT = 60 * 60
LATEST_BACKUP_TIMESTAMP = 'latest'
PUBLIC_BACKUP_TIMESTAMP = 'public'
REGRESSIONS_GCS_PATH_SUFFIX = '_regressions'

RSYNC_ERROR_REGEX = (br'CommandException:\s*(\d+)\s*files?/objects? '
                     br'could not be copied/removed')

MAX_SYNC_ERRORS = 10


class CorpusStorage(object):
    """Minio Storage corpus."""

    def __init__(self,
                 project_id: UUID,
                 fuzz_target_id: UUID,
                 log_results=True,
                 kind=CorpusTypes.CORPUS,
                 ):
        """Inits the Corpus.

        Args:
          api_client: The CorpusApi client.
          project_id: The project ID.
          fuzz_target_id: The fuzz target ID.
        """
        self.api_client = get_api_client().storage_corpus_api
        self.project_id = project_id
        self.fuzz_target_id = fuzz_target_id
        self._log_results = log_results
        self.kind = kind

    def rsync_from_disk(self, directory):
        """Upload local files to Storage and remove files which do not exist locally.

        Args:
          directory: Path to directory to sync from.

        Returns:
          A bool indicating whether or not the command succeeded.
        """
        legalize_files(directory)
        files = [{'name': os.path.basename(file), 'content': open(file, 'rb').read(), 'content_type': 'application/octet-stream'} for file in shell.get_files_list(directory)]
        try:
          self.api_client.upload_corpus(self.project_id, self.fuzz_target_id, files, self.kind)
          return True
        except Exception as e:
          return False

    def rsync_to_disk(self,directory):
        """Download corpus files from pingu_sdk remote path.

        Args:
          directory: Path to directory to sync to.

        Returns:
          A bool indicating whether or not the command succeeded.
        """
        try:
          shell.create_directory(directory, create_intermediates=True)
          corpus_data = self.api_client.download_corpus(self.project_id, self.fuzz_target_id, self.kind)
          with open(os.path.join(directory, 'corpus.zip'), 'wb') as f:
              f.write(corpus_data)
          shutil.unpack_archive(os.path.join(directory, 'corpus.zip'), directory)
          return True
        except Exception as e:
          return False

    def upload_files(self, file_paths):
        """Upload files to the Storage.

        Args:
          file_paths: A sequence of file paths to upload.

        Returns:
          A bool indicating whether or not the command succeeded.
        """
        if not file_paths:
            return False

        # Get a new file_paths iterator where all files have been renamed to be
        # legal on Windows.
        try:
            file_paths = legalize_filenames(file_paths)
            files = [{'name': os.path.basename(file), 'content': open(file, 'rb').read(), 'content_type': 'application/octet-stream'} for file in file_paths]
            return self.api_client.upload_corpus(self.project_id, self.fuzz_target_id, files, self.kind)
        except Exception as e:
            logs.log_error(f"Failed to corpus upload files: {e}")
            return False


class FuzzTargetCorpus(CorpusStorage):
    """Engine fuzzer (libFuzzer, AFL) specific corpus."""

    def __init__(self,
                 project_id: UUID,
                 fuzz_target_id: UUID,
                 log_results=True,
                 include_regressions=False,
                 kind=CorpusTypes.CORPUS):
        """Inits the FuzzTargetCorpus.

        Args:
          project_id: The project ID.
          fuzz_target_id: The fuzz target ID.

        Raises:
          RuntimeError: If the required environment variables are not set.
        """

        super().__init__(
            project_id,
            fuzz_target_id,
            log_results=log_results,
            kind=kind,
        )

        self._regressions_corpus = CorpusStorage(
            project_id,
            fuzz_target_id,
            log_results=log_results,
            kind=kind
        ) if include_regressions else None

    def rsync_from_disk(self, directory):
        """Upload local files to CS and remove files which do not exist locally.

        Overridden to have additional logging.

        Args:
          directory: Path to directory to sync to.
        Returns:
          A bool indicating whether or not the command succeeded.
        """
        result = super().rsync_from_disk(directory)

        num_files = _count_corpus_files(directory)
        if self._log_results:
            logs.log('%d corpus files uploaded for %s.' %
                     (num_files, self.fuzz_target_id))

        return result

    def rsync_to_disk(self, directory):
        """Run gsutil to download corpus files from pingu_sdk.GCS.

        Overridden to have additional logging.

        Args:
          directory: Path to directory to sync to.

        Returns:
          A bool indicating whether or not the command succeeded.
        """
        result = super().rsync_to_disk(directory)
        if not result:
            return False

        # Checkout additional regressions corpus if set and ignore the result.
        if self._regressions_corpus:
            regressions_dir = os.path.join(directory, 'regressions')
            self._regressions_corpus.rsync_to_disk(regressions_dir)

        num_files = _count_corpus_files(directory)
        if self._log_results:
            logs.log('%d corpus files downloaded for %s.' %
                     (num_files, self.fuzz_target_id))

        return result

    def get_regressions_corpus_url(self):
        """Return cs path to directory containing crash regressions."""
        return f""


def _count_corpus_files(directory):
    """Count the number of corpus files."""
    return shell.get_directory_file_count(directory)


def backup_corpus(corpus: FuzzTargetCorpus, directory):
    """Backup corpus to CS.

    Args:
      corpus: The CorpusStorage object.
      directory: The directory to backup.

    Returns:
      A bool indicating whether or not the command succeeded.
    """
    return corpus.rsync_from_disk(directory, kind=CorpusTypes.BACKUP)

