import os
from pingu_sdk.config.local_config import Config
import six

PROJECT_PATH = 'project'

class ProjectConfig(Config):
    """Project Config class helper."""

    def __init__(self):
        super(ProjectConfig, self).__init__(PROJECT_PATH)

    def set_environment(self):
        """Sets environment vars from project config."""
        env_variable_values = self.get('env')
        if not env_variable_values:
            return

        for variable, value in six.iteritems(env_variable_values):
            if variable in os.environ:
                # Don't override existing values.
                continue

            os.environ[variable] = str(value)
