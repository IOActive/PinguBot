
"""Get values / settings from pingu_sdk.local configuration."""

import os
import yaml

from pingu_sdk.system import errors, environment, memoize

CACHE_SIZE = 1024
YAML_FILE_EXTENSION = '.yaml'

SEPARATOR = '.'

REDIS_PATH = 'redis.config'

class Config(object):
    """Config class helper."""

    def __init__(self, root=None, *args, **kwargs):  # pylint: disable=keyword-arg-before-vararg
        self._root = root.format(*args, **kwargs) if root is not None else None
        self._config_dir = environment.get_config_directory()
        self._cache = memoize.FifoInMemory(CACHE_SIZE)

        # Check that config directory is valid.
        if not self._config_dir:
            raise errors.BadConfigError(self._config_dir)

        elif not os.path.exists(self._config_dir):
            os.mkdir(self._config_dir)

    def sub_config(self, path):
        """Return a new config with a new sub-root."""
        if self._root:
            new_root = self._root + SEPARATOR + path
        else:
            new_root = path

        return Config(root=new_root)

    def _get_helper(self, key_name='', default=None,
                    value_is_relative_path=False):
        """Helper for get and get_absolute_functions."""
        if self._root:
            key_name = self._root + SEPARATOR + key_name if key_name else self._root

        if not key_name:
            raise errors.InvalidConfigKey(key_name)

        cache_key_name = self._cache.get_key(self._get_helper,
                                             (key_name, value_is_relative_path), {})
        value = self._cache.get(cache_key_name)
        if value is not None:
            return value

        value = self._search_key(self._config_dir, key_name, value_is_relative_path)
        if value is None:
            return default

        self._cache.put(cache_key_name, value)
        return value

    def get(self, key_name='', default=None):
        """Get key value using a key name."""
        return self._get_helper(key_name, default=default)

    def get_absolute_path(self, key_name='', default=None):
        """Get absolute path of key value using a key name."""
        return self._get_helper(
            key_name, default=default, value_is_relative_path=True)
    
    def _load_yaml_file(self, yaml_file_path):
        """Load yaml file and return parsed contents."""
        with open(yaml_file_path) as f:
            try:
                return yaml.safe_load(f.read())
            except Exception:
                raise errors.ConfigParseError(yaml_file_path)


    def _find_key_in_yaml_file(self, yaml_file_path, search_keys, full_key_name,
                            value_is_relative_path):
        """Find a key in a yaml file."""
        if not os.path.isfile(yaml_file_path):
            return None

        result = self._load_yaml_file(yaml_file_path)

        if not search_keys:
            # Give the entire yaml file contents.
            # |value_is_relative_path| is not applicable here.
            return result

        for search_key in search_keys:
            if not isinstance(result, dict):
                raise errors.InvalidConfigKey(full_key_name)

            if search_key not in result:
                return None

            result = result[search_key]

        if value_is_relative_path:
            yaml_directory = os.path.dirname(yaml_file_path)
            if isinstance(result, list):
                result = [os.path.join(yaml_directory, str(i)) for i in result]
            else:
                result = os.path.join(yaml_directory, str(result))

        return result


    def _get_key_location(self, search_path, full_key_name):
        """Get the path of the the yaml file and the key components given a full key
    name."""
        key_parts = full_key_name.split(SEPARATOR)
        dir_path = search_path

        # Find the directory components of the key path
        for i, search_key in enumerate(key_parts):
            search_path = os.path.join(dir_path, search_key)
            if os.path.isdir(search_path):
                # Don't allow both a/b/... and a/b.yaml
                if os.path.isfile(search_path + YAML_FILE_EXTENSION):
                    raise errors.InvalidConfigKey(full_key_name)

                dir_path = search_path
            else:
                # The remainder of the key path is a yaml_filename.key1.key2...
                key_parts = key_parts[i:]
                break
        else:
            # The entirety of the key reference a directory.
            key_parts = []

        if key_parts:
            return dir_path, key_parts[0] + YAML_FILE_EXTENSION, key_parts[1:]

        return dir_path, '', []


    def _validate_root(self, search_path, root):
        """Validate that a root is valid."""
        if root is None:
            return True

        directory, filename, search_keys = self._get_key_location(search_path, root)

        if not filename:
            # _get_key_location already validated that the directory exists, so the root
            # is valid.
            return True

        # Check that the yaml file and keys exist.
        yaml_path = os.path.join(self, directory, filename)
        return (self._find_key_in_yaml_file(
            yaml_path, search_keys, root, value_is_relative_path=False) is not None)


    def _search_key(self, search_path, full_key_name, value_is_relative_path):
        """Search the key in a search path."""
        directory, filename, search_keys = self._get_key_location(search_path,
                                                            full_key_name)

        # Search in the yaml file.
        yaml_path = os.path.join(directory, filename)
        return self._find_key_in_yaml_file(yaml_path, search_keys, full_key_name,
                                    value_is_relative_path)

