
"""Classes for dealing with FuzzerStats."""

import datetime
import itertools
import json
import os
import random
import re
from typing import List
from uuid import uuid4
import uuid

from pingu_sdk.config.project_config import ProjectConfig
from pingu_sdk.datastore.data_constants import coverage_information_date_to_string
from pingu_sdk.fuzzing.stats_uploader import StatsUploader
from pingu_sdk.metrics import logs
from pingu_sdk.system import environment, shell
from pingu_sdk.utils import utils
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

STATS_FILE_EXTENSION = '.stats2'

PERFORMANCE_REPORT_VIEWER_PATH = '/performance-report/{fuzzer}/{job}/{date}'

JOB_RUN_SCHEMA = {
    'fields': [{
        'name': 'testcases_executed',
        'type': 'INTEGER',
        'mode': 'NULLABLE'
    }, {
        'name': 'build_revision',
        'type': 'INTEGER',
        'mode': 'NULLABLE'
    }, {
        'name': 'new_crashes',
        'type': 'INTEGER',
        'mode': 'NULLABLE'
    }, {
        'name': 'job_id',
        'type': 'STRING',
        'mode': 'NULLABLE'
    }, {
        'name': 'timestamp',
        'type': 'FLOAT',
        'mode': 'NULLABLE'
    }, {
        'name':
            'crashes',
        'type':
            'RECORD',
        'mode':
            'REPEATED',
        'fields': [{
            'name': 'crash_type',
            'type': 'STRING',
            'mode': 'NULLABLE'
        }, {
            'name': 'is_new',
            'type': 'BOOLEAN',
            'mode': 'NULLABLE'
        }, {
            'name': 'crash_state',
            'type': 'STRING',
            'mode': 'NULLABLE'
        }, {
            'name': 'security_flag',
            'type': 'BOOLEAN',
            'mode': 'NULLABLE'
        }, {
            'name': 'count',
            'type': 'INTEGER',
            'mode': 'NULLABLE'
        }]
    }, {
        'name': 'known_crashes',
        'type': 'INTEGER',
        'mode': 'NULLABLE'
    }, {
        'name': 'fuzzer',
        'type': 'STRING',
        'mode': 'NULLABLE'
    }, {
        'name': 'kind',
        'type': 'STRING',
        'mode': 'NULLABLE'
    }]
}


class FuzzerStatsException(Exception):
    """Fuzzer stats exception."""


class BaseRun(object):
    """Base run."""

    VALID_FIELDNAME_PATTERN = re.compile(r'[a-zA-Z][a-zA-Z0-9_]*')

    def __init__(self, fuzzer_id, project_id, job_id, binary, build_revision, timestamp):
        self._stats_data = {
            'project_id': str(project_id),
            'fuzzer_id': str(fuzzer_id),
            'binary': binary,
            'job_id': str(job_id),
            'build_revision': build_revision,
            'timestamp': timestamp,
        }

    def __getitem__(self, key):
        return self._stats_data.__getitem__(key)

    def __setitem__(self, key, value):
        if not re.compile(self.VALID_FIELDNAME_PATTERN):
            raise ValueError('Invalid key name.')

        return self._stats_data.__setitem__(key, value)

    def __delitem__(self, key):
        return self._stats_data.__delitem__(key)

    def __contains__(self, key):
        return self._stats_data.__contains__(key)

    def to_json(self):
        """Return JSON representation of the stats."""
        return json.dumps(self._stats_data)

    def update(self, other):
        """Update stats with a dict."""
        self._stats_data.update(other)

    @property
    def data(self):
        return self._stats_data

    @property
    def kind(self):
        return self._stats_data['kind']

    @property
    def fuzzer_id(self):
        return self._stats_data['fuzzer_id']
    
    @property
    def project_id(self):
        return self._stats_data['project_id']
    
    @property
    def binary(self):
        return self._stats_data['binary']

    @property
    def job_id(self):
        return self._stats_data['job_id']

    @property
    def build_revision(self):
        return self._stats_data['build_revision']

    @property
    def timestamp(self):
        return self._stats_data['timestamp']

    @staticmethod
    def from_json(json_data):
        """Convert json to the run."""
        try:
            data = json.loads(json_data)
        except (ValueError, TypeError):
            return None

        if not isinstance(data, dict):
            return None

        result = None
        try:
            kind = data['kind']
            if kind == 'TestcaseRun':
                result = TestcaseRun(f"{data['fuzzer_id']}_{data['project_id']}_{data['binary']}",
                                     data['job_id'],
                                     data['build_revision'], data['timestamp'])
            elif kind == 'JobRun':
                result = JobRun(f"{data['fuzzer_id']}_{data['project_id']}_{data['binary']}",
                                data['job_id'], data['build_revision'],
                                data['timestamp'], data['testcases_executed'],
                                data['new_crashes'], data['known_crashes'],
                                data.get('crashes'))
        except KeyError:
            return None

        if result:
            result.update(data)
        return result


class JobRun(BaseRun):
    """Represents stats for a particular job run."""

    SCHEMA = JOB_RUN_SCHEMA

    # `crashes` is a new field that will replace `new_crashes` and `old_crashes`.
    def __init__(self, fuzzer_id, project_id, job_id, binary, build_revision, timestamp,
                 number_of_testcases, new_crashes, known_crashes, crashes):
        super(JobRun, self).__init__(fuzzer_id, project_id, job_id, binary, build_revision, timestamp)
        self._stats_data.update({
            'kind': 'JobRun',
            'testcases_executed': number_of_testcases,
            'new_crashes': new_crashes,
            'known_crashes': known_crashes,
            'crashes': crashes
        })


class TestcaseRun(BaseRun):
    """Represents stats for a particular testcase run."""

    SCHEMA = None

    def __init__(self, fuzzer_id, project_id, job_id, binary, build_revision, timestamp):
        super(TestcaseRun, self).__init__(fuzzer_id, project_id, job_id, binary, build_revision, timestamp)
        self._stats_data.update({
            'kind': 'TestcaseRun',
        })

        source = environment.get_value('STATS_SOURCE')
        if source:
            self._stats_data['source'] = source

    @staticmethod
    def get_stats_filename(testcase_file_path):
        """Get stats filename for the given testcase."""
        return testcase_file_path + STATS_FILE_EXTENSION

    @staticmethod
    def read_from_disk(testcase_file_path, delete=False):
        """Read the TestcaseRun for the given testcase."""
        stats_file_path = TestcaseRun.get_stats_filename(testcase_file_path)
        if not os.path.exists(stats_file_path):
            return None

        fuzzer_run = None
        with open(stats_file_path) as f:
            fuzzer_run = BaseRun.from_json(f.read())

        if delete:
            shell.remove_file(stats_file_path)

        return fuzzer_run

    @staticmethod
    def write_to_disk(testcase_run, testcase_file_path):
        """Write the given TestcaseRun for |testcase_file_path| to disk."""
        if not testcase_run:
            return

        stats_file_path = TestcaseRun.get_stats_filename(testcase_file_path)
        with open(stats_file_path, 'w') as f:
            f.write(testcase_run.to_json())


def upload_stats(stats_list: List[BaseRun], filename=None):
    """Upload the fuzzer run to the bigquery bucket. Assumes that all the stats
  given are for the same fuzzer/job run."""
    if not stats_list:
        logs.log_error('Failed to upload fuzzer stats: empty stats.')
        return

    assert isinstance(stats_list, list)

    kind = stats_list[0].kind
    fuzzer_id = stats_list[0].fuzzer_id
    binary = stats_list[0].binary
    project_id = stats_list[0].project_id
    job_id = stats_list[0].job_id
    
    fuzz_target = get_api_client().fuzz_target_api.get_fuzz_target_by_keyName(fuzzer_id=fuzzer_id, binary=binary)
    
    stats_storage = StatsUploader(project_id=project_id, fuzz_target_id=fuzz_target.id, job_id=job_id)


    # Group all stats for fuzz targets.    
    if not filename:
        # Generate a random filename.
        filename = '%016x' % random.randint(0, (1 << 64) - 1) + '.json'

    # Handle runs that bleed into the next day.
    timestamp_start_of_day = lambda s: utils.utc_date_to_timestamp(
        datetime.datetime.utcfromtimestamp(s.timestamp).date())
    stats_list.sort(key=lambda s: s.timestamp)

    files = []
    for timestamp, stats in itertools.groupby(stats_list, timestamp_start_of_day):
        upload_data = '\n'.join(stat.to_json() for stat in stats)
        files.append({'name': filename, 'content': upload_data, 'content_type': 'application/json'})

    if not stats_storage.upload_stats(kind=kind, files=files):
        logs.log_error('Failed to upload Stats.')


def get_fuzzer_project_binary_from_full_name(fuzzer_name):
    """Return fuzzing engine name if it exists, or |fuzzer_name|."""
    # THe fuzzer name is split in 3 exact peace as the binary may containt _ or -
    split = fuzzer_name.split('_')
    return split[0], split[1], split[2]

def dataset_name(fuzzer_name):
    """Get the stats dataset name for the given |fuzzer_name|."""
    return fuzzer_name.replace('-', '_') + '_stats'
