from typing import List
from pingu_sdk.datastore.models.crash_stats import CrashStats
from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client


def upload_crash_stats(crashes_stats: List[dict]):
    for index, crash_stats in enumerate(crashes_stats):      
        # Validate the crash stats casting to CrashStats model
        insert_erros = []
        try:
            cs = CrashStats(**crash_stats)
            # Upload the crash stats to a remote server or database
            get_api_client().crash_stats_api.add_crash_stats(cs)
            
        except Exception as e:
            insert_erros.append({"index": index, "crash_stats": crash_stats})
            continue
        
    return insert_erros