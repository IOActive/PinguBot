"""Fuzzer log utilities."""

import datetime
import os
from uuid import UUID

from pingu_sdk.datastore.pingu_api.pingu_api_client import get_api_client

DATE_FORMAT = '%Y-%m-%d'
TIME_FORMAT = '%H:%M:%S:%f'

LOG_EXTENSION = '.log'
LOG_PATH_FORMAT = DATE_FORMAT + '/' + TIME_FORMAT

def get_log_relative_path(log_time, file_extension=None):
    """Generate a relative path for a log using the given time.
    Args:
        log_time: A datetime object.
        file_extension: A string appended to the end of the log file name.
        LOG_EXTENSION is used if None.
    Returns:
        A string containing name of the log file.
    """
    if file_extension is None:
        file_extension = LOG_EXTENSION

    return log_time.strftime(LOG_PATH_FORMAT) + file_extension


def upload_to_logs(project_id: UUID, job_id: UUID, contents, time=None, task_id: UUID = "", fuzzer_id: UUID = "", file_extension=""):
    """Upload file contents to log directory using LogsApi.
    Args:
        project_id: UUID of the project.
        job_id: UUID of the job.
        contents: String containing log to be uploaded.
        time: A datetime object used to generate filename for the log.
        task_id: Task ID.
        fuzzer_id: Fuzzer ID.
    """
    if not time:
        time = datetime.datetime.utcnow()

    files = [{
        'name': f"{get_log_relative_path(time)}{file_extension}",
        'content': contents,
        'content_type': 'text/plain'
    }]

    
    get_api_client().storage_logs_api.upload_logs(project_id, job_id, 'fuzzer', files, task_id, fuzzer_id)


def upload_script_log(project_id: UUID, job_id: UUID, log_contents, fuzzer_id: UUID = ""):
    """Upload logs to script logs using LogsApi.
    Args:
        project_id: UUID of the project.
        job_id: UUID of the job.
        log_contents: String containing log to be uploaded.
        task_id: Task ID.
        fuzzer_id: Fuzzer ID.
    """
    if log_contents and log_contents.strip():
        upload_to_logs(project_id, job_id, 'fuzzer', log_contents, fuzzer_id=fuzzer_id)
        
        
def upload_bot_log(project_id: UUID, job_id: UUID, log_files, task_id: str = ""):
    """Upload logs to bot logs using LogsApi.
    Args:
        project_id: UUID of the project.
        job_id: UUID of the job.
        log_contents: String containing log to be uploaded.
        task_id: Task ID.
        fuzzer_id: Fuzzer ID.
    """
    files = []
    
    for log_file in log_files:
        with open(log_file, "rb") as log:                    
            try:
                log_name = log.name.split('/')[-1]
                log_content = log.read()
                file = {
                    'name': log_name,
                    'content': log_content,
                    'content_type': 'text/plain'
                }
                files.append(file)
            except Exception as e:
                pass
    
    get_api_client().storage_logs_api.upload_logs(project_id, job_id, 'bot', files, task_id)
